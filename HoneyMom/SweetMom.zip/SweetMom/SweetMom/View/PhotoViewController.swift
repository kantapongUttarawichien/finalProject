//
//  PhotoViewController.swift
//  SweetMom
//
//  Created by kantapong on 21/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import AVFoundation
import Vision
import CoreML
import FirebaseFirestore

class PhotoViewController: UIViewController {
    
    let FoddModel = ImageClassifier()
    var dataUser : [User]?
    var cal : Int?
    
    lazy var popUpWindow: PopUpWindow = {
           let view = PopUpWindow()
           view.translatesAutoresizingMaskIntoConstraints = false
           view.layer.cornerRadius = 8
           view.delegate = self
           return view
       }()
       
       let visualEffectView: UIVisualEffectView = {
           let blurEffect = UIBlurEffect(style: .dark)
           let view = UIVisualEffectView(effect: blurEffect)
           view.translatesAutoresizingMaskIntoConstraints = false
           return view
       }()
    
     let captureButton: UIButton = {
            let button = UIButton(type: .system)
            button.layer.cornerRadius = 0
            button.setImage(UIImage(named: "iconCapture")?.withRenderingMode(.alwaysOriginal), for: .normal)
            button.imageView?.contentMode = .scaleAspectFill
            //button.tintColor = .red
            button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
            button.addTarget(self, action: #selector(cameraButtonTouch), for: .touchUpInside)
            return button
        }()
    
    let saveLabel: UILabel = {
        let label = UILabel()
        label.text = "Save"
        label.textColor = .white
        label.font = UIFont.Opun(size: 16)
        label.numberOfLines = 0
        return label
    }()
    
    let scopeImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconScope")
        image.contentMode =  .scaleAspectFit
        image.layer.masksToBounds = true
        return image
    }()

        var captureSession = AVCaptureSession()
        var backCamera: AVCaptureDevice?
        var frontCamera: AVCaptureDevice?
        var currentCamera: AVCaptureDevice?
        var photoOutput: AVCapturePhotoOutput?
        var cameraPreviewLayer: AVCaptureVideoPreviewLayer?
        var image:UIImage?
           
        override func viewDidLoad() {
            super.viewDidLoad()
            
            view.backgroundColor = .darkPink
            navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
            navigationController?.navigationBar.shadowImage = UIImage()
            
//-----------------------------------------------------------------------------------------------------------------
            
            view.addSubview(captureButton)
            view.addSubview(saveLabel)
            view.addSubview(scopeImage)
            view.addSubview(visualEffectView)
            
            captureButton.anchor(nil, left: nil, bottom: saveLabel.topAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 5, rightConstant: 0, widthConstant: 70, heightConstant: 70)
            captureButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
            
            saveLabel.anchor(nil, left: nil, bottom: view.safeAreaLayoutGuide.bottomAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 10, rightConstant: 0, widthConstant: 0, heightConstant: 0)
            saveLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
            
            scopeImage.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
            scopeImage.centerYAnchor.constraint(equalTo: view.centerYAnchor,constant: -20).isActive = true
            scopeImage.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
            
             visualEffectView.anchor(view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
            visualEffectView.alpha = 0
           
            
//-----------------------------------------------------------------------------------------------------------------
            
            setupCaptureSession()
            setupDevice()
            setupInputOutput()
            setupPreviewLayer()
            startRunningCaptureSession()
        }
        @objc func cameraButtonTouch() {
            let settings = AVCapturePhotoSettings()
            photoOutput?.capturePhoto(with: settings, delegate: self)
    //        Preview.image = self.image
    //        present(Preview, animated: true, completion: nil)
        }
    
        func setupCaptureSession() {
               captureSession.sessionPreset = AVCaptureSession.Preset.photo
           }
           
        func setupDevice() {
               let deviceDiscoverySession = AVCaptureDevice.DiscoverySession(deviceTypes: [AVCaptureDevice.DeviceType.builtInWideAngleCamera], mediaType: AVMediaType.video, position: AVCaptureDevice.Position.unspecified)
               let devices = deviceDiscoverySession.devices
               
               for device in devices{
                   if device.position == AVCaptureDevice.Position.back {
                       backCamera = device
                   }else if device.position == AVCaptureDevice.Position.front{
                       frontCamera = device
                   }
               }
               
               currentCamera = backCamera
           }

        func setupInputOutput() {
               do {
                   let captureDeviceInput = try AVCaptureDeviceInput(device: currentCamera!)
                   captureSession.addInput(captureDeviceInput)
                   photoOutput = AVCapturePhotoOutput()
                   photoOutput?.setPreparedPhotoSettingsArray([AVCapturePhotoSettings(format:[AVVideoCodecKey: AVVideoCodecType.jpeg])], completionHandler: nil)
                   captureSession.addOutput(photoOutput!)
               } catch {
                   print(error)
               }
           }
           
           func setupPreviewLayer() {
               cameraPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
               cameraPreviewLayer?.videoGravity = AVLayerVideoGravity.resizeAspectFill
               cameraPreviewLayer?.connection?.videoOrientation = AVCaptureVideoOrientation.portrait
               cameraPreviewLayer?.frame = self.view.frame
               self.view.layer.insertSublayer(cameraPreviewLayer!, at: 0)
           }
           
           func startRunningCaptureSession() {
               captureSession.startRunning()
           }
           
           override var prefersStatusBarHidden: Bool {
               return true
           }
    func checkImage(setImage: UIImage){
        //-----Set Up Model-----//
        if let model = try?VNCoreMLModel(for: FoddModel.model){
            let request = VNCoreMLRequest(model: model){ (request, error) in
                if let reqults = request.results as? [VNClassificationObservation]{
                    for classification in reqults where classification.confidence > 0.8 {
                        print("\(classification.identifier)")
                        let db = Firestore.firestore()
                        db.collection("food").getDocuments(){ (querySnapshot, err) in
                            if let err = err {
                                print("Error getting documents: \(err)")
                            } else {
                              
                                for document in (querySnapshot?.documents)! {
                                   
                                    if document.documentID == classification.identifier {
                                        if let name = document.data()["name"]as? String,
                                            let calorie = document.data()["calorie"] as? Double,
                                            let carbohydrate = document.data()["carbohydrate"] as? Double,
                                            let fat = document.data()["fat"] as? Double,
                                            let gi = document.data()["gi"] as? Double,
                                            let protein = document.data()["protein"] as? Double,
                                            let sodium = document.data()["sodium"] as? Double{
//                                            print("\(name)\n\(calorie)\n\(carbohydrate)\n\(fat)\n\(gi)\n\(protein)\n\(sodium)")
                                            self.showPopUp(data: "\(classification.identifier)", dataCalorie: calorie, dataCarbohydrate: carbohydrate, dataFat: fat, dataGi: gi, dataProtein: protein, dataSodium: sodium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        //-----CHECK IMAGE-----//
            let image = setImage
            if let imageData = image.pngData() {
                let handler = VNImageRequestHandler(data: imageData, options: [:])
                try? handler.perform([request])
               
            }
        }
    }
    func showPopUp(data: String, dataCalorie: Double, dataCarbohydrate: Double, dataFat: Double, dataGi: Double, dataProtein: Double, dataSodium: Double){
        if data == "Table" {
//            self.showPopUp(data: "ไม่พบข้อมูลอาหาร", dataCalorie: String)
             popUpWindow.Titlehead.text = "ไม่พบข้อมูลอาหาร"
        }else {
            let pop = PopUpWindow()
            pop.cal = Int(dataCalorie)
            popUpWindow.Titlehead.text = data
            popUpWindow.numCal.text = "\(Int(dataCalorie))"
            popUpWindow.numGI.text = "\(Int(dataGi))"
            popUpWindow.progressView.progress = Float(dataCalorie) / Float(2095) //dataUser[0].userCaloriesPerDay / Double(cal)
            popUpWindow.calMaxLabel.text = "2500"
            popUpWindow.numberFat.text = "\(dataFat)"
            popUpWindow.numberProtein.text = "\(dataProtein)"
            popUpWindow.numberCarbohydrate.text = "\(dataCarbohydrate)"
            popUpWindow.numberSodium.text = "\(dataSodium)"
            popUpWindow.button.isHidden = true
            popUpWindow.iconTree.isHidden = true
            popUpWindow.iconHome.isHidden = true
            popUpWindow.contentTextlabel.isHidden = true
            popUpWindow.TitleTextlabel.isHidden = true
            view.addSubview(popUpWindow)
            popUpWindow.anchor(view.safeAreaLayoutGuide.topAnchor, left: nil, bottom: view.safeAreaLayoutGuide.bottomAnchor, right: nil, topConstant: 20, leftConstant: 0, bottomConstant: 40, rightConstant: 0, widthConstant: view.frame.width - 64, heightConstant: 0)
            popUpWindow.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
            popUpWindow.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            popUpWindow.alpha = 0
        
            UIView.animate(withDuration: 0.5) {
                self.visualEffectView.alpha = 1
                self.popUpWindow.alpha = 1
                self.popUpWindow.transform = CGAffineTransform.identity
            }
        }
    }
}
extension PhotoViewController: AVCapturePhotoCaptureDelegate{
        func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
            if let imageData = photo.fileDataRepresentation(){
                image = UIImage(data: imageData)
                checkImage(setImage: image!)
                //Preview.image = self.image
               //present(Preview, animated: true, completion: nil)
                //UIImageWriteToSavedPhotosAlbum(self.image!, nil, nil, nil)
                //performSegue(withIdentifier: "showPhotos", sender: nil)
        }
    }
}

extension PhotoViewController: PopUpDelegate {

    func handleDismissal() {
        UIView.animate(withDuration: 0.5, animations: {
            self.visualEffectView.alpha = 0
            self.popUpWindow.alpha = 0
            self.popUpWindow.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        }) { (_) in
            self.popUpWindow.removeFromSuperview()
            print("Did remove pop up window..")
        }
    }
}
  
