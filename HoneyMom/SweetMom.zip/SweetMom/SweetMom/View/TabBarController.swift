//
//  TabBarController.swift
//  SweetMom
//
//  Created by kantapong on 21/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import FirebaseAuth


class TabBarController: UITabBarController,UITabBarControllerDelegate {
    
    private var handle: AuthStateDidChangeListenerHandle? 

    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.delegate = self
        tabBar.tintColor = .darkPink
        tabBar.barTintColor = UIColor.white
        setUI()
        setdata()
    }
//    override func viewWillAppear(_ animated: Bool) {
//           handle = Auth.auth().addStateDidChangeListener { (auth, user) in 
//               if Auth.auth().currentUser != nil {
//             // User is signed in.
//                   self.setUI()
//               } else {
//             // No user is signed in.
//                   self.view.window?.rootViewController = UINavigationController(rootViewController: LoginViewController())
//                   self.view.window?.makeKeyAndVisible()
//               }
//           }
//       }
//       override func viewWillDisappear(_ animated: Bool) {
//           super.viewWillDisappear(animated)
//           Auth.auth().removeStateDidChangeListener(handle!)
//       }

    fileprivate func tabBarNavigation(unselectedImage: UIImage?, selectdImage: UIImage?, title: String?, badgeValue: String?, rootViewController: UIViewController = UIViewController()) -> UINavigationController {
           let navController = UINavigationController(rootViewController: rootViewController)
           
           navController.tabBarItem.image = unselectedImage
           navController.tabBarItem.selectedImage = selectdImage
           navController.tabBarItem.imageInsets = UIEdgeInsets(top: -5, left: 6, bottom: 0, right: 6)
           navController.tabBarItem.title = title
           navController.tabBarItem.badgeColor = .red
           navController.tabBarItem.badgeValue = badgeValue
           
           return navController
           
       }
    func setUI() {
        let homeController = self.tabBarNavigation(unselectedImage: UIImage(named: "iconHome"), selectdImage: UIImage(named: "iconHome")!.withRenderingMode(.alwaysOriginal), title: "HOME", badgeValue: nil, rootViewController: HomeViewController())
        
        let blogController = self.tabBarNavigation(unselectedImage: UIImage(named: "iconBlog"), selectdImage: UIImage(named: "iconBlog")!.withRenderingMode(.alwaysOriginal), title: "BLOG", badgeValue: nil, rootViewController: BlogViewController())
        
        let photoController = self.tabBarNavigation(unselectedImage: UIImage(named: "iconPhoto")!.withRenderingMode(.alwaysOriginal), selectdImage: UIImage(named: "iconPhotoChange"), title: nil, badgeValue: nil, rootViewController: PhotoViewController())
        
        let chatController = self.tabBarNavigation(unselectedImage: UIImage(named: "iconChat"), selectdImage:UIImage(named: "iconChat")!.withRenderingMode(.alwaysOriginal), title: "CHAT",  badgeValue: nil, rootViewController: ChatViewController())
               
        let shopController = self.tabBarNavigation(unselectedImage: UIImage(named: "iconShop"), selectdImage: UIImage(named: "iconShop")!.withRenderingMode(.alwaysOriginal), title: "SHOP", badgeValue: nil, rootViewController: ShopViewController())
         
        viewControllers = [homeController,blogController,photoController,chatController,shopController]
    }
    func setdata() {
   
    }
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
           let index = viewControllers?.lastIndex(of: viewController)
           if index == 2{
                 tabBar.tintColor = .darkPink
                tabBar.barTintColor = UIColor.black
                self.tabBar.layer.masksToBounds = true
                self.tabBar.isTranslucent = true
                self.tabBar.barStyle = .black
                self.tabBar.layer.cornerRadius = 20
                self.tabBar.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            if let items = tabBarController.tabBar.items {
               for item in items {
                  item.title = nil
                 item.imageInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
               }
            }
           }else{
            tabBar.tintColor = .darkPink
            tabBar.barTintColor = UIColor.white
             self.tabBar.layer.cornerRadius = 0
             self.tabBar.layer.masksToBounds = false
            if let items = tabBarController.tabBar.items {
                items[0].title = "HOME"
                items[1].title = "BLOG"
                items[3].title = "CHAT"
                items[4].title = "SHOP"
                for item in items {
                  item.imageInsets = UIEdgeInsets(top: -5, left: 6, bottom: 0, right: 6)
                }
            }
        }
        return true
    }
}

