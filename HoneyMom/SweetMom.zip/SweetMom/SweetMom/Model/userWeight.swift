//
//  userWeight.swift
//  SweetMom
//
//  Created by kantapong on 28/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import Firebase

class userWeight {
    
    var WeightUpdate : Double
    var date : String
   
    
    init(WeightUpdate : Double, date : String) {
        
            self.WeightUpdate = WeightUpdate
            self.date = date
        
       }
    
//    static func user() -> [User] {
//        var userProfile = [User]()
//        userProfile.append(User(userFullName: "Kanyawee Kittiprakarn", userEmail: "Kanyawee@hotmail.com", userPassword: "123456789", userWeight: [56,54,53], userWeightBefore: 52, userHeight: 158, userAge: 22, userGestationalAge: 16, uerBloodSugar: [156]))
//
//        return userProfile
//    }
    
    
}
