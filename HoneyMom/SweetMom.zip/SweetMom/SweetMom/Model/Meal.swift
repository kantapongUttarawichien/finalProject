//
//  Meal.swift
//  SweetMom
//
//  Created by kantapong on 8/2/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class Meal {
   
    var name : String
    var id : Int
    
    init(name : String, id : Int){
        self.name = name
        self.id = id

    }
    static func meal() -> [Meal] {
        var usermeal = [Meal]()
        usermeal.append(Meal(name: "มื้อเช้า", id: 0))
        usermeal.append(Meal(name: "มื้อว่างเช้า", id: 1))
        usermeal.append(Meal(name: "มื้อกลางวัน", id: 2))
        usermeal.append(Meal(name: "มื้อว่างบ่าย", id: 3))
        usermeal.append(Meal(name: "มื้อเย็น", id: 4))
        
        return usermeal
    }
}
