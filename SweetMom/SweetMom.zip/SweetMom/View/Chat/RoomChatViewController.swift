//
//  ViewController.swift
//  testApp
//
//  Created by kantapong on 28/10/2562 BE.
//  Copyright © 2562 kantapong. All rights reserved.
//

import UIKit
import AVFoundation
import FirebaseDatabase
struct Chatessage {
    let profile: String
    let text: String
    let isIncoming: Bool
    let date: String
    let time:  String
    let error: Bool
    
}
class RoomChatViewController: UIViewController , UITableViewDelegate , UITableViewDataSource , UITextViewDelegate {
    
    var titleRoom = ""
    var cellId = "Cell"
    var chatMessages : [ Chatessage ] = []
    
    //var  Messages = [[Chatessage]]()
    
    lazy var tableview : UITableView = {
         let tableview = UITableView()
         tableview.delegate = self
         tableview.dataSource = self
         tableview.tableFooterView = UIView()
         tableview.showsVerticalScrollIndicator = false
         tableview.backgroundColor = .none//UIColor(white: 0.95, alpha: 1 )
        
         return tableview
     }()
    
    let speechSynthesizer = AVSpeechSynthesizer()
    
    let backButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(named: "back"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.tintColor = .darkPink
        button.addTarget(self, action: #selector(handleBack), for: .touchUpInside)
        return button
    }()
    
    let bottom: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.darkPink
        return view
    }()
    
    let bottomII: UIView = {
          let view = UIView()
          view.backgroundColor = UIColor.darkPink
          return view
    }()
    
    let boxtest: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 15
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 5
        view.layer.shadowOpacity = 0.2
        return view
    }()
    let test: UITextView = {
        let textView = UITextView()
       
        textView.attributedText = NSAttributedString(string: "พิมพ์ข้อความของคุณ ที่นี่", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 16), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.2)])
        textView.backgroundColor = .clear
        textView.textColor = UIColor.darkPink
        textView.font = UIFont.boldSystemFont(ofSize: 16)
        return textView
    }()
    func textViewDidBeginEditing(_ test: UITextView) {
        if test.textColor == UIColor.darkPink {
            test.text = nil
            test.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ test: UITextView) {
        if test.text.isEmpty {
            test.text = "พิมพ์ข้อความของคุณ ที่นี่"
            test.textColor = UIColor.darkPink
            test.font = UIFont.boldSystemFont(ofSize: 16)
        }
    }
    let send: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(#imageLiteral(resourceName: "iconBlog"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.tintColor = UIColor.white
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(sendTo), for: .touchUpInside)
        return button
    }()
    
    private var chatRoomRef :DatabaseReference!

    override func viewDidLoad() {
        super.viewDidLoad()
        let back = UIBarButtonItem(image: UIImage(named: "iconBack"), style: .plain, target: self, action: #selector(handleBack))
        back.tintColor = UIColor.black
        navigationItem.leftBarButtonItem = back
        view.backgroundColor = UIColor(white: 1, alpha: 1 )
        //view.backgroundColor = UIColor(patternImage: UIImage(named: "backgound.png")!)
        navigationItem.title = "Chatbot"
        
        self.navigationController?.navigationBar.barTintColor = UIColor.darkPink
        
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: UIFont.Opun(size: 20), NSAttributedString.Key.foregroundColor: UIColor.black]

        view.addSubview(tableview)
        self.test.delegate = self
        view.addSubview(bottomII)
        view.addSubview(bottom)
      
        bottom.addSubview(boxtest)
        boxtest.addSubview(test)
        bottom.addSubview(send)
        tableview.register(TableViewCell.self, forCellReuseIdentifier: cellId)
        tableview.transform = CGAffineTransform (scaleX: 1,y: -1);
      
        tableview.anchor(view.safeAreaLayoutGuide.topAnchor, left: view.safeAreaLayoutGuide.leftAnchor, bottom: bottom.topAnchor, right: view.safeAreaLayoutGuide.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        bottomII.anchor(nil, left: view.safeAreaLayoutGuide.leftAnchor, bottom: view.bottomAnchor, right: view.safeAreaLayoutGuide.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 50)
        
        bottom.anchor(nil, left: view.safeAreaLayoutGuide.leftAnchor, bottom: view.safeAreaLayoutGuide.bottomAnchor, right: view.safeAreaLayoutGuide.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 50)
        
        send.anchor(bottom.topAnchor, left: boxtest.rightAnchor, bottom: nil, right: bottom.safeAreaLayoutGuide.rightAnchor, topConstant: 10, leftConstant: 15, bottomConstant: 0, rightConstant: 15, widthConstant: 30, heightConstant: 30)
                
        boxtest.anchor(bottom.topAnchor, left: bottom.leftAnchor, bottom: nil, right: send.leftAnchor, topConstant: 5, leftConstant: 20, bottomConstant: 0, rightConstant: 15, widthConstant: 0, heightConstant: 40)
        
        test.anchor(boxtest.topAnchor, left: boxtest.leftAnchor, bottom: nil, right: boxtest.rightAnchor, topConstant: 5, leftConstant: 15, bottomConstant: 0, rightConstant: 15, widthConstant: 0, heightConstant: 30)
       
  
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        // Do any additional setup after loading the view.
        tableview.separatorStyle = .none
        
   }
    override func viewWillAppear(_ animated: Bool) {
        navigationItem.title = titleRoom
//-----------------------------------------------------------------------------------------------------------------
        //Firebase
         self.chatRoomRef = Database.database().reference(withPath: titleRoom + "kan")

//-----------------------------------------------------------------------------------------------------------------
        populateMessages()
    }
    private func populateMessages() {
        
        self.chatRoomRef.observe(.childAdded) { snapshot in
            let messageDictionary = snapshot.value as? [String:Any] ?? [:]
            
            guard let senderId = messageDictionary["senderId"] as? String,
                let senderDisplayName = messageDictionary["senderDisplayName"] as? String else { return }
            let text = messageDictionary["text"] as? String
            let date = messageDictionary["senderTime"] as? String
            
            if text != nil {
                self.addMessage(senderId: senderId, senderDisplayName: senderDisplayName, text: text!, senderTime: date!)
            }
        }
    }
    private func addMessage(senderId :String, senderDisplayName :String, text :String, senderTime:String) {
        
        if senderId == "kan" {
            self.chatMessages.insert(Chatessage.init(profile: "profile",text: text, isIncoming: false, date: "\(Date.dateFromCustomString(customString: " "))",time: senderTime, error: true), at: 0)
        } else {
            self.chatMessages.insert(Chatessage.init(profile: "profile",text: text, isIncoming: true, date: "\(Date.dateFromCustomString(customString: " "))",time: senderTime, error: true), at: 0)
        }
         self.tableview.reloadData()
    }
    @objc func handleBack(){
        navigationController?.popViewController(animated: true)
      }
    
    func scrollIndexPathToBottom(indexPath: IndexPath) {
      
       tableview.scrollToRow(at: indexPath, at: .bottom, animated: true)
    }

    @objc func sendTo(){
           guard let savesend = test.text else{ return }
        if savesend != "" && savesend != "พิมพ์ข้อความของคุณ ที่นี่"{
            
            let currentDateTime = Date()
            let formatter = DateFormatter()
            formatter.timeStyle = .short
            
//-----------------------------------------------------------------------------------------------------------------
            //Firebase
            let messageData = [
                "senderId" : "kan",
                "senderDisplayName" : "kan",
                "senderTime" : formatter.string(from: currentDateTime),
                "text" : savesend
            ]
            let chatMessageRef = self.chatRoomRef.childByAutoId()
            chatMessageRef.setValue(messageData)

//-----------------------------------------------------------------------------------------------------------------

            self.tableview.reloadData()
           test.text = nil
        }else{
            
        }
       }
    func speechAndText(text: String) {
        let speechUtterance = AVSpeechUtterance(string: text)
        speechSynthesizer.speak(speechUtterance)
        
        let currentDateTime = Date()
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        
        chatMessages.insert(Chatessage.init(profile: "exercise_mom-3",text: text, isIncoming: true, date: "\(Date.dateFromCustomString(customString: " "))",time: formatter.string(from: currentDateTime), error: true), at: 0)
        
        self.tableview.reloadData()
        
//        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseInOut, animations: {
//            self.chipResponse.text = text
//        }, completion: nil)
        
    }
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return Messages.count
//    }
    class DateHeaderLabel: UILabel {
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            textColor = UIColor.white
           
            backgroundColor = .mediumBlue
            textAlignment = .center
            translatesAutoresizingMaskIntoConstraints = false
                   
        }
        
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        override var intrinsicContentSize: CGSize {
            
            let originalContentSize = super.intrinsicContentSize
            let height = originalContentSize.height + 12
            font = UIFont.boldSystemFont(ofSize: 14)
            layer.cornerRadius = height/2
            layer.masksToBounds = true
            return CGSize(width: originalContentSize.width + 20, height: height)
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chatMessages.count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath)as! TableViewCell
          cell.selectionStyle = .none
        let chatmessage = chatMessages[indexPath.row]
        cell.chatessage = chatmessage
        cell.time.text = "\(chatmessage.time)"
        cell.check = chatmessage.isIncoming
        cell.profileImage.image = UIImage(named: chatmessage.profile)
        cell.transform = CGAffineTransform(scaleX: 1, y: -1)

        return cell
       }
    @objc func keyboardWillShow(notification: NSNotification) {
           if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
               if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
                    //keyboardSize.height
               }
           }
       }
       
       @objc func keyboardWillHide(notification: NSNotification) {
           if self.view.frame.origin.y != 0 {
               self.view.frame.origin.y = 0
           }
       }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        view.endEditing(true)
    }
//    private override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        view.endEditing(true)
//    }
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//           self.view.endEditing(true)
//           
//       }
       

}

