//
//  ChatViewController.swift
//  SweetMom
//
//  Created by kantapong on 21/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class ChatViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    var setdata = Dietician.dietician()
    var name : String?
    
    let backgroundPage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "backgroundHomePage")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()
    
    lazy var collectionView: UICollectionView = {
        let collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewFlowLayout.init())
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()
    @objc func  notification() {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "นักโภชนาการ"
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font:UIFont.Opun(size: 20), NSAttributedString.Key.foregroundColor:UIColor.black]
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        navigationController?.navigationBar.shadowImage = UIImage()
         view.backgroundColor = .yellow
        
        let notification = UIBarButtonItem(image: #imageLiteral(resourceName: "iconBell").withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(ChatViewController.notification))
               
        navigationItem.rightBarButtonItems = [notification]
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        collectionView.isPagingEnabled = true
        collectionView.backgroundColor = .clear
        
        view.addSubview(backgroundPage)
        view.addSubview(collectionView)
        
        
        backgroundPage.anchor(view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        collectionView.anchor(view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, bottom: view.safeAreaLayoutGuide.bottomAnchor, right: view.rightAnchor, topConstant: 10, leftConstant: 0, bottomConstant: 20, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
         collectionView.register(chatCollectionViewCell.self, forCellWithReuseIdentifier: "cellId")
        
        // Do any additional setup after loading the view.
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return setdata.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
             return CGSize(width: view.frame.width , height: view.frame.height - 100)
         }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellId", for: indexPath) as! chatCollectionViewCell
//        if indexPath.row == 0 {
//                   cell.backgroundColor = UIColor.emerald
//               } else if indexPath.row == 1 {
//                   cell.backgroundColor = UIColor.ruby
//               } else if indexPath.row == 2 {
//                   cell.backgroundColor = UIColor.gold
//               }
        let group = setdata[indexPath.row]
        cell.name.text = group.dieticianFullName
        cell.education.text = group.education
        cell.work.text = group.work
        cell.imagHead.image = group.img
        cell.nextPage.tag = group.id
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
//    private func collectionView(_ tableView: UICollectionView, didSelectRowAt indexPath: IndexPath) {
//        let settingsController = RoomChatViewController()
//        settingsController.hidesBottomBarWhenPushed = true
//        name = setdata[indexPath.row].dieticianFullName
//        navigationController?.pushViewController(settingsController, animated: true)
//    }
    @objc func nextPage(_sender: UIButton) {
        let settingsController = RoomChatViewController()
        settingsController.hidesBottomBarWhenPushed = true
        if _sender.tag == 0 {
            settingsController.titleRoom = setdata[0].dieticianFullName
        }else  if _sender.tag == 1 {
            settingsController.titleRoom = setdata[1].dieticianFullName
        }else {
            settingsController.titleRoom = setdata[2].dieticianFullName
        }
        navigationController?.pushViewController(settingsController, animated: true)
    }
    
    
  

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
