//
//  BloodSugarViewController.swift
//  SweetMom
//
//  Created by kantapong on 24/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import FirebaseFirestore
import FirebaseAuth

class BloodSugarViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource{
    
    let screenSizeWidth: CGFloat = UIScreen.main.bounds.width
    let screenSizeHeight: CGFloat = UIScreen.main.bounds.height
    var dataUser = [userBloodSugars]()
    let db = Firestore.firestore()
    
    lazy var backgroundBloodSugaPage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "backgroundHomePage")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()
    
    lazy var backgroundView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    lazy var boxBloodSugaView: UIView = {
          let view = UIView()
          view.backgroundColor = .white
          view.layer.cornerRadius = 8
          view.layer.shadowColor = UIColor.black.cgColor
          view.layer.shadowOffset = .zero
          view.layer.shadowRadius = 8
          view.layer.shadowOpacity = 0.2
          return view
      }()
      
      lazy var headUIView: UIView = {
          let view = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 60))
          let gradient = CAGradientLayer()
          view.clipsToBounds = true
          view.layer.maskedCorners = [.layerMinXMinYCorner /*top left corner*/, .layerMaxXMinYCorner /*top right corner*/]
          gradient.frame = view.bounds
          gradient.colors = [UIColor.darkPink.cgColor, UIColor.lightPink.cgColor]
          view.layer.cornerRadius = 8
          gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
          gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
          view.layer.addSublayer(gradient)
          return view
      }()

      lazy var titlehead: UILabel = {
          let label = UILabel()
          label.text = "บันทึกค่าน้ำตาลในเลือด"
          label.textColor = .white
          label.font = UIFont.Opun(size: 16)
          label.numberOfLines = 0
          return label
      }()
    
//-----------------------------------------------------------------------------------------------------------------

    lazy var bloodSugaView: UIView = {
        let view = UIView()
        return view
    }()
       
    lazy var bloodSugaIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconProfile_Color")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        return image
    }()
      
    lazy var bloodSugaTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "น้ำตาลในเลือด(ล่าสุด)", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 8), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .numberPad
        textField.leftViewMode = UITextField.ViewMode.always
        return textField
    }()
       
    lazy var bloodSugaline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
    lazy var bloodSugaButton: UIButton = {
        let button = UIButton(type: .system)
        let gradientLayer = CAGradientLayer()
        button.frame = CGRect(x: 0, y: 0, width: 400, height: 50)
        gradientLayer.frame = button.frame
        gradientLayer.colors = [UIColor.lightPink.cgColor, UIColor.darkPink.cgColor]
        button.layer.insertSublayer(gradientLayer, at: 0)
        button.clipsToBounds = true
        button.layer.cornerRadius = 8
        button.setTitle("Save", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 16)
        button.addTarget(self, action: #selector(addBloodSarug), for: .touchUpInside)
        return button
    }()

//-----------------------------------------------------------------------------------------------------------------

    lazy var tableBloodSuga: UILabel = {
        let label = UILabel()
        label.text = "ตารางค่าน้ำตาลในเลือด"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 14)
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    lazy var tableDateBloodSuga: UILabel = {
        let label = UILabel()
        label.text = "วันที่"
        label.textColor = .black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
    lazy var tableNumberBloodSuga: UILabel = {
        let label = UILabel()
        label.text = "ค่าน้ำตาล"
        label.textColor = .black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
    lazy var tableUnitBloodSuga: UILabel = {
        let label = UILabel()
       label.text = "หน่วย"
        label.textColor = .black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
    
    
//-----------------------------------------------------------------------------------------------------------------
   
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.tableFooterView = UIView()
        tableView.showsVerticalScrollIndicator = false
           
        return tableView
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .brown
        navigationItem.title = "น้ำตาลในเลือด"
        navigationItem.hidesBackButton = true
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font:UIFont.Opun(size: 20), NSAttributedString.Key.foregroundColor:UIColor.black]
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
              navigationController?.navigationBar.shadowImage = UIImage()
         let backButton = UIBarButtonItem(image: UIImage(named: "iconBack")?.withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(handleBack))
        navigationItem.leftBarButtonItem = backButton
        
//-----------------------------------------------------------------------------------------------------------------
        
        bloodSugaTextField.delegate = self
        view.addSubview(backgroundBloodSugaPage)
        view.addSubview(backgroundView)
        view.addSubview(boxBloodSugaView)
        boxBloodSugaView.addSubview(headUIView)
        headUIView.addSubview(titlehead)
        boxBloodSugaView.addSubview(bloodSugaView)
        boxBloodSugaView.addSubview(bloodSugaButton)
        
        backgroundBloodSugaPage.anchor(view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        backgroundView.anchor(view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 130, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        boxBloodSugaView.anchor(nil, left: nil, bottom: backgroundView.topAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: -110, rightConstant: 0, widthConstant: screenSizeWidth - 50, heightConstant: 220)
         boxBloodSugaView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        headUIView.anchor(boxBloodSugaView.topAnchor, left: boxBloodSugaView.leftAnchor, bottom: nil, right: boxBloodSugaView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 60)
        
        titlehead.anchor(headUIView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
               titlehead.centerXAnchor.constraint(equalTo: headUIView.centerXAnchor).isActive = true
        
        bloodSugaView.anchor(headUIView.bottomAnchor, left: boxBloodSugaView.leftAnchor, bottom: nil, right: boxBloodSugaView.rightAnchor, topConstant: 30, leftConstant: 30, bottomConstant: 0, rightConstant: 30, widthConstant: 0, heightConstant: 40)
        
       bloodSugaButton.anchor(bloodSugaView.bottomAnchor, left: bloodSugaView.leftAnchor, bottom: nil, right: bloodSugaView.rightAnchor, topConstant: 20, leftConstant: 15, bottomConstant: 0, rightConstant: 15, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------

        bloodSugaView.addSubview(bloodSugaIcon)
        bloodSugaView.addSubview(bloodSugaTextField)
        bloodSugaView.addSubview(bloodSugaline)
               
        bloodSugaIcon.anchor(bloodSugaView.topAnchor, left: bloodSugaView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                      
        bloodSugaTextField.anchor(bloodSugaView.topAnchor, left: bloodSugaView.leftAnchor, bottom: nil, right: bloodSugaView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                      
        bloodSugaline.anchor(nil, left: bloodSugaView.leftAnchor, bottom: bloodSugaView.bottomAnchor, right: bloodSugaView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------
        
        backgroundView.addSubview(tableBloodSuga)
        backgroundView.addSubview(tableDateBloodSuga)
        backgroundView.addSubview(tableNumberBloodSuga)
        backgroundView.addSubview(tableUnitBloodSuga)
        
        tableBloodSuga.anchor(boxBloodSugaView.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        tableBloodSuga.centerXAnchor.constraint(equalTo: boxBloodSugaView.centerXAnchor).isActive = true
        
        tableDateBloodSuga.anchor(tableBloodSuga.bottomAnchor, left: boxBloodSugaView.leftAnchor, bottom: nil, right: nil, topConstant: 10, leftConstant: 20, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        tableNumberBloodSuga.anchor(tableBloodSuga.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        tableNumberBloodSuga.centerXAnchor.constraint(equalTo: boxBloodSugaView.centerXAnchor).isActive = true
        
        tableUnitBloodSuga.anchor(tableBloodSuga.bottomAnchor, left: nil, bottom: nil, right: boxBloodSugaView.rightAnchor, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------
        
        tableView.register(addTableViewCell.self, forCellReuseIdentifier: "cellId")
        tableView.separatorStyle = .none
 
        backgroundView.addSubview(tableView)
        
        tableView.anchor(tableNumberBloodSuga.bottomAnchor, left: boxBloodSugaView.leftAnchor, bottom: backgroundView.bottomAnchor, right: boxBloodSugaView.rightAnchor, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------
        
    }
    @objc func handleBack(){
      navigationController?.popViewController(animated: true)
        
    }
    @objc func addBloodSarug(){
        guard let add = bloodSugaTextField.text else { return }
        var bloodNew = 0.00
        bloodNew = (add as NSString).doubleValue
        if bloodNew != 0.00 {
            let user = Auth.auth().currentUser
            guard user != nil else { return }
            let uid = user!.uid
            db.collection("users").document(uid).collection("BloodSugars").document().setData(["bloodSugar": bloodNew,"date": "\(Date.dateFromCustomString(customString: "\(Date())"))"]){(error) in
                
                if error != nil {
                    // Show error message
                    print("Error saving user data")
                }else {
                    var dateUp = ""
                    dateUp = "\(Date.dateFromCustomString(customString:""))"
                    self.dataUser.insert(userBloodSugars.init(BloodSugarUpdate: bloodNew, date: "\(Date.FromCustomString(customString: dateUp))"), at: 0)
                    
                    self.tableView.reloadData()
                    self.bloodSugaTextField.text = ""
                }
            }
        }else{
            
        }
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         self.view.endEditing(true)
     
     }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataUser.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "cellId", for: indexPath) as! addTableViewCell
        
            cell.selectionStyle = .none
            let group = dataUser[indexPath.row]
        cell.numberLabel.text = "\(Int(group.BloodSugarUpdate))"
            cell.dateLabel.text = "\(group.date)"
            return cell
    }
     override func viewWillAppear(_ animated: Bool) {
//-----------------------------------------------------------------------------------------------------------------
            //Firebase
                    
            let user = Auth.auth().currentUser
                 guard user != nil else { return }
                 let uid = user!.uid
             db.collection("users").document(uid).collection("BloodSugars").order(by: "date", descending: true)
                                .getDocuments() { (querySnapshot, err) in
                                    if let err = err {
                                        print("Error getting documents: \(err)")
                                    } else {
                                            for document in querySnapshot!.documents {
                                                //print("\(document.documentID) => \(document.data())")
                                                
    //                                            self.dataUser.insert(userWeights.init(WeightUpdate: document.data()["Weight"] as! Double, date: "\(Date.FromCustomString(customString: document.data()["date"] as! String))"), at: 0)
                                                self.dataUser.append(userBloodSugars.init(BloodSugarUpdate: document.data()["bloodSugar"] as! Double, date: "\(Date.FromCustomString(customString: document.data()["date"] as! String))"))
                                                
                                                //print("\(document.data()["Weight"] as! Double)")
                                                print("\(document.data()["date"] as! String)")
                                                print("__________________________________________________________")
                                               
                                                self.tableView.reloadData()
                                            }
                                    }
                                }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

