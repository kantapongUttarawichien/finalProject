//
//  WeightViewController.swift
//  SweetMom
//
//  Created by kantapong on 24/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import FirebaseFirestore
import FirebaseAuth

class WeightViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource{
    
    let screenSizeWidth: CGFloat = UIScreen.main.bounds.width
    let screenSizeHeight: CGFloat = UIScreen.main.bounds.height
    var dataUser = [userWeights]()
  
    
    let db = Firestore.firestore()
    
    lazy var backgroundWeightPage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "backgroundHomePage")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()
    
    lazy var backgroundView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    lazy var boxWeightView: UIView = {
          let view = UIView()
          view.backgroundColor = .white
          view.layer.cornerRadius = 8
          view.layer.shadowColor = UIColor.black.cgColor
          view.layer.shadowOffset = .zero
          view.layer.shadowRadius = 8
          view.layer.shadowOpacity = 0.2
          return view
      }()
      
      lazy var headUIView: UIView = {
          let view = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 60))
          let gradient = CAGradientLayer()
          view.clipsToBounds = true
          view.layer.maskedCorners = [.layerMinXMinYCorner /*top left corner*/, .layerMaxXMinYCorner /*top right corner*/]
          gradient.frame = view.bounds
          gradient.colors = [UIColor.darkPink.cgColor, UIColor.lightPink.cgColor]
          view.layer.cornerRadius = 8
          gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
          gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
          view.layer.addSublayer(gradient)
          return view
      }()

      lazy var titlehead: UILabel = {
          let label = UILabel()
          label.text = "บันทึกค่าน้ำหนักตัว"
          label.textColor = .white
          label.font = UIFont.Opun(size: 16)
          label.numberOfLines = 0
          return label
      }()
    
//-----------------------------------------------------------------------------------------------------------------

    lazy var weightView: UIView = {
        let view = UIView()
        return view
    }()
       
    lazy var weightIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconProfile_Color")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        return image
    }()
      
    lazy var weightTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "น้ำหนัก(ปัจจุบัน)", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 8), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .numberPad
        textField.leftViewMode = UITextField.ViewMode.always
        return textField
    }()
       
    lazy var weightline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
    lazy var weightButton: UIButton = {
        let button = UIButton(type: .system)
        let gradientLayer = CAGradientLayer()
        button.frame = CGRect(x: 0, y: 0, width: 400, height: 50)
        gradientLayer.frame = button.frame
        gradientLayer.colors = [UIColor.lightPink.cgColor, UIColor.darkPink.cgColor]
        button.layer.insertSublayer(gradientLayer, at: 0)
        button.clipsToBounds = true
        button.layer.cornerRadius = 8
        button.setTitle("Save", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 16)
        button.addTarget(self, action: #selector(addWeight), for: .touchUpInside)
        return button
    }()

//-----------------------------------------------------------------------------------------------------------------

    lazy var tableWeight: UILabel = {
        let label = UILabel()
        label.text = "ตารางค่าน้ำหนักตัว"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 14)
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    lazy var tableDateWeight: UILabel = {
        let label = UILabel()
        label.text = "วันที่"
        label.textColor = .black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
    lazy var tableNumberWeight: UILabel = {
        let label = UILabel()
        label.text = "น้ำหนัก"
        label.textColor = .black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
    lazy var tableUnitWeight: UILabel = {
        let label = UILabel()
       label.text = "หน่วย"
        label.textColor = .black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
    
    
//-----------------------------------------------------------------------------------------------------------------
   
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.tableFooterView = UIView()
        tableView.showsVerticalScrollIndicator = false
           
        return tableView
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "น้ำหนักตัว"
        navigationItem.hidesBackButton = true
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font:UIFont.Opun(size: 20), NSAttributedString.Key.foregroundColor:UIColor.black]
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
              navigationController?.navigationBar.shadowImage = UIImage()
         let backButton = UIBarButtonItem(image: UIImage(named: "iconBack")?.withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(handleBack))
        navigationItem.leftBarButtonItem = backButton
        
//-----------------------------------------------------------------------------------------------------------------
        
        weightTextField.delegate = self
        view.addSubview(backgroundWeightPage)
        view.addSubview(backgroundView)
        view.addSubview(boxWeightView)
        boxWeightView.addSubview(headUIView)
        headUIView.addSubview(titlehead)
        boxWeightView.addSubview(weightView)
        boxWeightView.addSubview(weightButton)
        
        backgroundWeightPage.anchor(view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        backgroundView.anchor(view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 130, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        boxWeightView.anchor(nil, left: nil, bottom: backgroundView.topAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: -110, rightConstant: 0, widthConstant: screenSizeWidth - 50, heightConstant: 220)
         boxWeightView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        headUIView.anchor(boxWeightView.topAnchor, left: boxWeightView.leftAnchor, bottom: nil, right: boxWeightView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 60)
        
        titlehead.anchor(headUIView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
               titlehead.centerXAnchor.constraint(equalTo: headUIView.centerXAnchor).isActive = true
        
        weightView.anchor(headUIView.bottomAnchor, left: boxWeightView.leftAnchor, bottom: nil, right: boxWeightView.rightAnchor, topConstant: 30, leftConstant: 30, bottomConstant: 0, rightConstant: 30, widthConstant: 0, heightConstant: 40)
        
        weightButton.anchor(weightView.bottomAnchor, left: weightView.leftAnchor, bottom: nil, right: weightView.rightAnchor, topConstant: 20, leftConstant: 15, bottomConstant: 0, rightConstant: 15, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------

        weightView.addSubview(weightIcon)
        weightView.addSubview(weightTextField)
        weightView.addSubview(weightline)
               
        weightIcon.anchor(weightView.topAnchor, left: weightView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                      
        weightTextField.anchor(weightView.topAnchor, left: weightView.leftAnchor, bottom: nil, right: weightView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                      
        weightline.anchor(nil, left: weightView.leftAnchor, bottom: weightView.bottomAnchor, right: weightView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------
        
        backgroundView.addSubview(tableWeight)
        backgroundView.addSubview(tableDateWeight)
        backgroundView.addSubview(tableNumberWeight)
        backgroundView.addSubview(tableUnitWeight)
        
        tableWeight.anchor(boxWeightView.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        tableWeight.centerXAnchor.constraint(equalTo: boxWeightView.centerXAnchor).isActive = true
        
        tableDateWeight.anchor(tableWeight.bottomAnchor, left: boxWeightView.leftAnchor, bottom: nil, right: nil, topConstant: 10, leftConstant: 20, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        tableNumberWeight.anchor(tableWeight.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        tableNumberWeight.centerXAnchor.constraint(equalTo: boxWeightView.centerXAnchor).isActive = true
        
        tableUnitWeight.anchor(tableWeight.bottomAnchor, left: nil, bottom: nil, right: boxWeightView.rightAnchor, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------
        
        tableView.register(addTableViewCell.self, forCellReuseIdentifier: "cellId")
        tableView.separatorStyle = .none
 
        backgroundView.addSubview(tableView)
        
        tableView.anchor(tableNumberWeight.bottomAnchor, left: boxWeightView.leftAnchor, bottom: backgroundView.bottomAnchor, right: boxWeightView.rightAnchor, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------
        
    }
    @objc func handleBack(){
        navigationController?.popViewController(animated: true)
        
    }
    @objc func addWeight(){
        guard let add = weightTextField.text else { return }
        var weightNew = 0.00
        weightNew = (add as NSString).doubleValue
        if weightNew != 0.00 {
//-----------------------------------------------------------------------------------------------------------------
//Firebase
        let user = Auth.auth().currentUser
        guard user != nil else { return }
        let uid = user!.uid
        db.collection("users").document(uid).collection("Weights").document().setData(["Weight": weightNew,"date": "\(Date.dateFromCustomString(customString: "\(Date())"))"]){(error) in
            
            if error != nil {
                // Show error message
                print("Error saving user data")
            }else {
                var dateUp = ""
                dateUp = "\(Date.dateFromCustomString(customString:""))"
                self.dataUser.insert(userWeights.init(WeightUpdate: weightNew, date: "\(Date.FromCustomString(customString: dateUp))"), at: 0)
                
                self.tableView.reloadData()
                self.weightTextField.text = ""
            }
        }
        }else{
            
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
     
     }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataUser.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellId", for: indexPath) as! addTableViewCell
        
        cell.selectionStyle = .none
        let group = dataUser[indexPath.row]
        cell.numberLabel.text = "\(Int(group.WeightUpdate))"
        
        cell.dateLabel.text = "\(group.date)"
        return cell
    }
    override func viewWillAppear(_ animated: Bool) {
        
//-----------------------------------------------------------------------------------------------------------------
        //Firebase
                
        let user = Auth.auth().currentUser
             guard user != nil else { return }
             let uid = user!.uid
         db.collection("users").document(uid).collection("Weights").order(by: "date", descending: true)
                            .getDocuments() { (querySnapshot, err) in
                                if let err = err {
                                    print("Error getting documents: \(err)")
                                } else {
                                        for document in querySnapshot!.documents {
                                            //print("\(document.documentID) => \(document.data())")
                                            
//                                            self.dataUser.insert(userWeights.init(WeightUpdate: document.data()["Weight"] as! Double, date: "\(Date.FromCustomString(customString: document.data()["date"] as! String))"), at: 0)
                                            self.dataUser.append(userWeights.init(WeightUpdate: document.data()["Weight"] as! Double, date: "\(Date.FromCustomString(customString: document.data()["date"] as! String))"))
                                            
                                            //print("\(document.data()["Weight"] as! Double)")
                                            print("\(document.data()["date"] as! String)")
                                            print("__________________________________________________________")
                                            print(Date())
                                            self.tableView.reloadData()
                                        }
                                }
                            }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
