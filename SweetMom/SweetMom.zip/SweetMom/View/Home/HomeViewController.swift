//
//  HomeViewController.swift
//  SweetMom
//
//  Created by kantapong on 21/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import Foundation
import FirebaseAuth
import FirebaseFirestore

class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITabBarControllerDelegate{
    
    let Photo = PopUpWindow()
    var dataUser = [User].self
    var dataMeal = Meal.meal()
    let screenSizeWidth: CGFloat = UIScreen.main.bounds.width
    let screenSizeHeight: CGFloat = UIScreen.main.bounds.height
    var timer = Timer()
    var addCal : Int = 0
    
    var water1Bool = false
    var water2Bool = false
    var water3Bool = false
    var water4Bool = false
    var water5Bool = false
    var water6Bool = false
    
    var BMI : Double = 0
    var BMR : Double = 0
    
    var weightThreeMonths : Double = 0.00
    var gainWeight : Double = 0.00
    var day : Double = 0.00
    var gainCal : Double = 0.00
    static var cal : Int = 0
    static var updateCal : Int?
    var sumCal : Double = 0.00
    var progessCal : Double = 0
   
    var userFullName : String = ""
    var userEmail : String = ""
    var userPassword : String = ""
    var userWeight = [userWeights]()
    var userWeightBefore : Double = 0.00
    var userHeight : Double = 0.00
    var userAge : Int = 0
    var userGestationalAge : Int = 0
    var uerBloodSugar : [Double] = [154,52]
    var userCaloriesPerDay : Double = 0.00
   
    let backgroundHomePage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "backgroundHomePage")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()
    
    var viewScroll: UIScrollView = {
         let view = UIScrollView()
         view.showsVerticalScrollIndicator = false
         return view
     }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    let boxCalView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.2
        return view
    }()
    
    let headUIView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 60))
        let gradient = CAGradientLayer()
        view.clipsToBounds = true
        view.layer.maskedCorners = [.layerMinXMinYCorner /*top left corner*/, .layerMaxXMinYCorner /*top right corner*/]
        gradient.frame = view.bounds
        gradient.colors = [UIColor.darkPink.cgColor, UIColor.lightPink.cgColor]
        view.layer.cornerRadius = 8
        gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        view.layer.addSublayer(gradient)
        return view
    }()

    let titlehead: UILabel = {
        let label = UILabel()
        label.text = "แคลอรี่ี่ควรได้รับ"
        label.textColor = .white
        label.font = UIFont.Opun(size: 16)
        label.numberOfLines = 0
        return label
    }()
    
    let calMinLabel: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.textColor = .darkGray
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    
    let progressView: UIProgressView = {
        let view = UIProgressView()
        view.progressImage = UIImage(named: "progress")
        view.progress = 0
        view.trackTintColor = .palePink
        view.progressViewStyle = .bar
        view.layer.cornerRadius = 15
        view.translatesAutoresizingMaskIntoConstraints = false
        view.clipsToBounds = true
        return view
    }()
    
    let calMaxLabel: UILabel = {
        let label = UILabel()
        label.text = "2500\nMax"
        label.textColor = .darkGray
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    let calLabel: UILabel = {
        let label = UILabel()
        label.text = "700"
        label.textColor = .darkBlue
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
    
    let lineCal: UIView = {
        let view = UIView()
        view.backgroundColor = .darkBlue
        return view
    }()
    
    let BloodView: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconBlood")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()

//-----------------------------------------------------------------------------------------------------------------
    
    let titleheadFood: UILabel = {
        let label = UILabel()
        label.text = "บันทึกอาหารประจำวัน"
        label.textColor = .black
        label.font = UIFont.Opun(size: 16)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var collectionView: UICollectionView = {
        let collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewFlowLayout.init())
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    let boxView: UIView = {
          let view = UIView()
          view.backgroundColor = .clear
          return view
      }()
    
    let boxbloodView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.2
        return view
    }()
    
    let titleheadBoxblood: UILabel = {
           let label = UILabel()
           label.text = "น้ำตาลในเลือด"
           label.textColor = .black
           label.font = UIFont.Opun(size: 14)
           label.numberOfLines = 0
           return label
    }()
    
    let lineBoxblood: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
    let bloodSugar: UILabel = {
        let label = UILabel()
        label.text = "120"
        label.textColor = .white
        label.font = UIFont.Opun(size: 40)
        label.numberOfLines = 0
        return label
    }()
    
    let statusBloodSugar: UILabel = {
        let label = UILabel()
        label.text = "ปกติ"
        label.textColor = .white
        label.font = UIFont.Opun(size: 20)
        label.numberOfLines = 0
        return label
    }()
    
    let addBloodButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .lightPink
        button.layer.cornerRadius = 8
        button.setTitle("บันทึกเพิ่ม", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 12)
        button.setImage(UIImage(named: "iconButton"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.tintColor = UIColor.whiteAlpha(alpha: 0.8)
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: -5, bottom: 10, right: 0)
        button.addTarget(self, action: #selector(nextPage), for: .touchUpInside)
        button.tag = 1
        return button
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    let boxspaceView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()

//-----------------------------------------------------------------------------------------------------------------
    
    let boxweightView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.2
        return view
    }()
    
    let titleheadBoxweight: UILabel = {
        let label = UILabel()
        label.text = "น้ำหนักของคุณ"
        label.textColor = .black
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
       
    let lineBoxweight: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
    let goalWeightText: UILabel = {
        let label = UILabel()
        label.text = "นน.เป้าหมาย"
        label.textColor = UIColor.black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
    
    let goalWeightNumber: UILabel = {
        let label = UILabel()
        label.text = "62"
        label.textColor = .lightPink
        label.font = UIFont.Opun(size: 20)
        label.numberOfLines = 0
        return label
    }()
    
    let lineBoxweightspace: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
    let weightText: UILabel = {
        let label = UILabel()
        label.text = "นน.ปัจจุบัน"
        label.textColor = UIColor.black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
       
    let weightNumber: UILabel = {
        let label = UILabel()
        label.text = "58"
        label.textColor = .lightPink
        label.font = UIFont.Opun(size: 20)
        label.numberOfLines = 0
        return label
    }()
    
    let addWeightButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .lightPink
        button.layer.cornerRadius = 8
        button.setTitle("บันทึกเพิ่ม", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 12)
        button.setImage(UIImage(named: "iconButton"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.tintColor = UIColor.whiteAlpha(alpha: 0.8)
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: -5, bottom: 10, right: 0)
        button.addTarget(self, action: #selector(nextPage), for: .touchUpInside)
        button.tag = 2
        return button
    }()

//-----------------------------------------------------------------------------------------------------------------
    
    let boxwaterView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.2
        return view
    }()
    
    let titleheadBoxwater: UILabel = {
        let label = UILabel()
        label.text = "น้ำที่ควรได้รับต่อวัน"
        label.textColor = .black
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    
    let titleheadBoxwaterNumber: UILabel = {
        let label = UILabel()
        label.text = "1.5 ลิตร"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 20)
        label.numberOfLines = 0
        return label
    }()
       
    let lineBoxwater: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
    let water1: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(drinkWater), for: .touchUpInside)
        button.tag = 0
        return button
    }()
    let water2: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(drinkWater), for: .touchUpInside)
        button.tag = 1
        return button
    }()
    let water3: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(drinkWater), for: .touchUpInside)
        button.tag = 2
        return button
    }()
    let water4: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(drinkWater), for: .touchUpInside)
        button.tag = 3
        return button
    }()
    let water5: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(drinkWater), for: .touchUpInside)
        button.tag = 4
        return button
    }()
    let water6: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(drinkWater), for: .touchUpInside)
        button.tag = 5
        return button
    }()
   
    
//-----------------------------------------------------------------------------------------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "ข้อมูลโดยรวม"
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font:UIFont.Opun(size: 20), NSAttributedString.Key.foregroundColor:UIColor.black]
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
              navigationController?.navigationBar.shadowImage = UIImage()
        
        let profile = UIBarButtonItem(image: #imageLiteral(resourceName: "iconProfile").withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(logoutView))
        
        navigationItem.rightBarButtonItems = [profile]
        
        collectionView.register(mealCollectionViewCell.self, forCellWithReuseIdentifier: "cellId")
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                   layout.scrollDirection = .horizontal
               }
        collectionView.isPagingEnabled = true
        collectionView.backgroundColor = .clear
        
//-----------------------------------------------------------------------------------------------------------------
       
        view.addSubview(backgroundHomePage)
        view.addSubview(viewScroll)
       
        
        backgroundHomePage.anchor(view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        viewScroll.anchor(view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, bottom: view.safeAreaLayoutGuide.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------
        
        viewScroll.addSubview(boxCalView)
        boxCalView.addSubview(headUIView)
        headUIView.addSubview(titlehead)
        boxCalView.addSubview(calMinLabel)
        boxCalView.addSubview(progressView)
        boxCalView.addSubview(calMaxLabel)
        boxCalView.addSubview(calLabel)
        boxCalView.addSubview(lineCal)
        
        boxCalView.anchor(viewScroll.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth - 50, heightConstant: 180)
        boxCalView.centerXAnchor.constraint(equalTo: viewScroll.centerXAnchor).isActive = true
        
        headUIView.anchor(boxCalView.topAnchor, left: boxCalView.leftAnchor, bottom: nil, right: boxCalView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 60)
        
        titlehead.anchor(headUIView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        titlehead.centerXAnchor.constraint(equalTo: headUIView.centerXAnchor).isActive = true
        
        calMinLabel.anchor(nil, left: boxCalView.leftAnchor, bottom: boxCalView.bottomAnchor, right: nil, topConstant: 0, leftConstant: 20, bottomConstant: 35, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        progressView.anchor(nil, left: calMinLabel.rightAnchor, bottom: boxCalView.bottomAnchor, right: nil, topConstant: 0, leftConstant: 10, bottomConstant: 40, rightConstant: 0, widthConstant: screenSizeWidth - 150, heightConstant: 30)
        
        calMaxLabel.anchor(nil, left: nil, bottom: boxCalView.bottomAnchor, right: boxCalView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 10, rightConstant: 20, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------
    
        viewScroll.addSubview(titleheadFood)
        viewScroll.addSubview(collectionView)
        
        titleheadFood.anchor(boxCalView.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        titleheadFood.centerXAnchor.constraint(equalTo: viewScroll.centerXAnchor).isActive = true
        
        collectionView.anchor(titleheadFood.bottomAnchor, left: view.leftAnchor, bottom: nil, right:  view.rightAnchor, topConstant: 10, leftConstant: 0, bottomConstant: 20, rightConstant: 0, widthConstant: 0, heightConstant: 220)
            
//-----------------------------------------------------------------------------------------------------------------
        
        viewScroll.addSubview(boxView)
        boxView.addSubview(boxbloodView)
        boxbloodView.addSubview(titleheadBoxblood)
        boxbloodView.addSubview(lineBoxblood)
        boxbloodView.addSubview(BloodView)
        BloodView.addSubview(bloodSugar)
        BloodView.addSubview(statusBloodSugar)
        boxbloodView.addSubview(addBloodButton)
        boxView.addSubview(boxspaceView)
        boxView.addSubview(boxweightView)
        
        boxView.anchor(collectionView.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 30, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth - 50, heightConstant: 240)
        boxView.centerXAnchor.constraint(equalTo: viewScroll.centerXAnchor).isActive = true
        
        boxbloodView.anchor(boxView.topAnchor, left: boxView.leftAnchor, bottom: boxView.bottomAnchor, right: boxspaceView.leftAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 240)
        
        titleheadBoxblood.anchor(boxbloodView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        titleheadBoxblood.centerXAnchor.constraint(equalTo: boxbloodView.centerXAnchor).isActive = true
        
        lineBoxblood.anchor(boxbloodView.topAnchor, left: boxbloodView.leftAnchor, bottom: nil, right: boxbloodView.rightAnchor, topConstant: 60, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 2)
        
        BloodView.anchor(lineBoxblood.bottomAnchor, left: boxbloodView.leftAnchor, bottom: nil, right: boxbloodView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 110)
        
        bloodSugar.anchor(nil, left: nil, bottom: BloodView.bottomAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 10, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        bloodSugar.centerXAnchor.constraint(equalTo: BloodView.centerXAnchor).isActive = true
        
        statusBloodSugar.anchor(nil, left: nil, bottom: BloodView.bottomAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        statusBloodSugar.centerXAnchor.constraint(equalTo: BloodView.centerXAnchor).isActive = true
        
        addBloodButton.anchor(nil, left: boxbloodView.leftAnchor, bottom: boxbloodView.bottomAnchor, right: boxbloodView.rightAnchor, topConstant: 0, leftConstant: 15, bottomConstant: 15, rightConstant: 15, widthConstant: 0, heightConstant: 40)
        //addBloodButton.centerXAnchor.constraint(equalTo: boxbloodView.centerXAnchor).isActive = true
        
        boxspaceView.anchor(boxView.topAnchor, left: nil, bottom: boxView.bottomAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 30, heightConstant: 240)
        boxspaceView.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
//-----------------------------------------------------------------------------------------------------------------
        
        boxweightView.addSubview(titleheadBoxweight)
        boxweightView.addSubview(lineBoxweight)
        boxweightView.addSubview(goalWeightText)
        boxweightView.addSubview(goalWeightNumber)
        boxweightView.addSubview(weightText)
        boxweightView.addSubview(weightNumber)
        boxweightView.addSubview(lineBoxweightspace)
        boxweightView.addSubview(addWeightButton)
        
        boxweightView.anchor(boxView.topAnchor, left: boxspaceView.rightAnchor, bottom: boxView.bottomAnchor, right: boxView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 240)
        
        titleheadBoxweight.anchor(boxweightView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        titleheadBoxweight.centerXAnchor.constraint(equalTo: boxweightView.centerXAnchor).isActive = true
               
        lineBoxweight.anchor(boxweightView.topAnchor, left: boxweightView.leftAnchor, bottom: nil, right: boxweightView.rightAnchor, topConstant: 60, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 2)
        
        goalWeightText.anchor(lineBoxweight.bottomAnchor, left: nil, bottom: nil, right: goalWeightNumber.leftAnchor, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        goalWeightText.centerXAnchor.constraint(equalTo: boxweightView.centerXAnchor, constant: -13).isActive = true
        
        goalWeightNumber.anchor(lineBoxweight.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        goalWeightNumber.centerXAnchor.constraint(equalTo: boxweightView.centerXAnchor, constant: 40).isActive = true
        
        lineBoxweightspace.anchor(goalWeightText.bottomAnchor, left: boxweightView.leftAnchor, bottom: nil, right: boxweightView.rightAnchor, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 2)
        
        weightText.anchor(lineBoxweightspace.bottomAnchor, left: nil, bottom: nil, right: weightNumber.leftAnchor, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        weightText.centerXAnchor.constraint(equalTo: boxweightView.centerXAnchor, constant: -13).isActive = true
               
        weightNumber.anchor(lineBoxweightspace.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        weightNumber.centerXAnchor.constraint(equalTo: boxweightView.centerXAnchor, constant: 40).isActive = true
        
        addWeightButton.anchor(nil, left: boxweightView.leftAnchor, bottom: boxweightView.bottomAnchor, right: boxweightView.rightAnchor, topConstant: 0, leftConstant: 15, bottomConstant: 15, rightConstant: 15, widthConstant: 0, heightConstant: 40)

//-----------------------------------------------------------------------------------------------------------------
       
        let stacView = UIStackView(arrangedSubviews: [water1,water2,water3,water4,water5,water6])
            stacView.distribution = .fillEqually
            stacView.spacing = 10
            stacView.axis = .horizontal
        
        viewScroll.addSubview(boxwaterView)
        boxwaterView.addSubview(titleheadBoxwater)
        boxwaterView.addSubview(titleheadBoxwaterNumber)
        boxwaterView.addSubview(lineBoxwater)
        boxwaterView.addSubview(stacView)
        
       
        
        boxwaterView.anchor(boxView.bottomAnchor, left: nil, bottom: viewScroll.bottomAnchor, right: nil, topConstant: 30, leftConstant: 0, bottomConstant: 30, rightConstant: 0, widthConstant: screenSizeWidth - 50, heightConstant: 180)
        boxwaterView.centerXAnchor.constraint(equalTo: viewScroll.centerXAnchor).isActive = true
        
        titleheadBoxwater.anchor(boxwaterView.topAnchor, left: boxwaterView.leftAnchor, bottom: nil, right: nil, topConstant: 15, leftConstant: 15, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        titleheadBoxwaterNumber.anchor(boxwaterView.topAnchor, left: nil, bottom: nil, right: boxwaterView.rightAnchor, topConstant: 8, leftConstant: 0, bottomConstant: 0, rightConstant: 15, widthConstant: 0, heightConstant: 0)
        
        lineBoxwater.anchor(boxwaterView.topAnchor, left: boxwaterView.leftAnchor, bottom: nil, right: boxwaterView.rightAnchor, topConstant: 60, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 2)
        
        stacView.anchor(boxwaterView.topAnchor, left: boxwaterView.leftAnchor, bottom: nil, right: boxwaterView.rightAnchor, topConstant: 100, leftConstant: 25, bottomConstant: 0, rightConstant: 25, widthConstant: screenSizeWidth - 100, heightConstant: 50)
        
     
    }
    func UpdateUIProgress() {
        timer  = Timer.scheduledTimer(timeInterval: 0.02,target:self,selector: #selector(HomeViewController.ProcessTimer),  userInfo:  nil,repeats:  true)
    }
    func setDataUser() {
        
            
        bloodSugar.text = "\(Int(uerBloodSugar[0]))"
        if uerBloodSugar[0] >= 0 && uerBloodSugar[0] <= 79{
            statusBloodSugar.text = "น้ำตาลต่ำ"
        }else if uerBloodSugar[0] >= 80 && uerBloodSugar[0] <= 126{
            statusBloodSugar.text = "ปกติ"
        }else if uerBloodSugar[0] >= 126  {
            statusBloodSugar.text = "น้ำตาลสูง"
        }

//-----------------------------------------------------------------------------------------------------------------

        BMI = userWeightBefore / ((userHeight / 100.00) * (userHeight / 100))
        BMR = 665 + ((9.6 * Double(userWeightBefore)) + ((1.8 * Double(userHeight)) - (4.7 * Double(userAge))))
        print("BMI : \(BMI)")

        if BMI >= 0 && BMI <= 20.99 {
            if userGestationalAge >= 0 && userGestationalAge <= 12 {
                weightThreeMonths = userWeightBefore + 2
                day =  12.00 - Double(userGestationalAge)
            }else  if userGestationalAge >= 13 && userGestationalAge <= 24 {
                weightThreeMonths = userWeightBefore + (8 + 2)
                day =  24.00 - Double(userGestationalAge)
            }else  if userGestationalAge >= 25 && userGestationalAge <= 36 {
                weightThreeMonths = userWeightBefore + (6 + (8 + 2))
                day =  36.00 - Double(userGestationalAge)
            }

            gainWeight = weightThreeMonths - userWeight[userWeight.count - 1].WeightUpdate
            gainCal = (gainWeight * 7000) / (day * 7)
            HomeViewController.cal = Int(gainCal + BMR)
            goalWeightNumber.text = "\(Int(userWeightBefore + (6 + (8 + 2))))"

        }else  if BMI >= 21 && BMI <= 26 {
            if userGestationalAge >= 0 && userGestationalAge <= 12 {
                weightThreeMonths = userWeightBefore + 2
                day =  12.00 - Double(userGestationalAge)
            }else  if userGestationalAge >= 13 && userGestationalAge <= 24 {
                weightThreeMonths = userWeightBefore + (7 + 2)
                day =  24.00 - Double(userGestationalAge)
            }else  if userGestationalAge >= 25 && userGestationalAge <= 36 {
                weightThreeMonths = userWeightBefore + (5 + (7 + 2))
                day =  36.00 - Double(userGestationalAge)
            }

            gainWeight = weightThreeMonths - userWeight[userWeight.count - 1].WeightUpdate
            gainCal = (gainWeight * 7000) / (day * 7)
            HomeViewController.cal = Int(gainCal + BMR)
            goalWeightNumber.text = "\(Int(userWeightBefore + (5 + (7 + 2))))"

        }else {
            if userGestationalAge >= 0 && userGestationalAge <= 12 {
                weightThreeMonths = userWeightBefore + 1
                day =  12.00 - Double(userGestationalAge)
            }else  if userGestationalAge >= 13 && userGestationalAge <= 24 {
                weightThreeMonths = userWeightBefore + (6 + 1)
                day =  24.00 - Double(userGestationalAge)
            }else  if userGestationalAge >= 25 && userGestationalAge <= 36 {
                weightThreeMonths = userWeightBefore + (4 + (6 + 1))
                day =  36.00 - Double(userGestationalAge)
            }

            gainWeight = weightThreeMonths - userWeight[userWeight.count - 1].WeightUpdate
            gainCal = (gainWeight * 7000) / (day * 7)
            HomeViewController.cal = Int(gainCal + BMR)
            goalWeightNumber.text = "\(Int(userWeightBefore + (4 + (6 + 1))))"

        }
        if HomeViewController.cal < 0 {
            userCaloriesPerDay = userCaloriesPerDay + Double((HomeViewController.updateCal ?? 0))
            calMaxLabel.text =  "0\nMax"
            progessCal = userCaloriesPerDay / Double(HomeViewController.cal)
            weightNumber.text = "\(Int(userWeight[userWeight.count - 1].WeightUpdate))"
            
        }else{
            userCaloriesPerDay = userCaloriesPerDay + Double((HomeViewController.updateCal ?? 0))
            calMaxLabel.text =  "\(HomeViewController.cal)\nMax"
            progessCal = userCaloriesPerDay / Double(HomeViewController.cal)
            weightNumber.text = "\(Int(userWeight[userWeight.count - 1].WeightUpdate))"
        }

    }
    @objc func ProcessTimer(){
        if progressView.progress <= Float(progessCal){
            progressView.progress += 0.02
            calLabel.text = "\(Int(userCaloriesPerDay))"
            calLabel.isHidden = true
            lineCal.isHidden = true
        }else{
            calLabel.isHidden = false
            lineCal.isHidden = false
            calLabel.anchor(nil, left: boxCalView.leftAnchor, bottom: progressView.topAnchor, right: nil, topConstant: 0, leftConstant: CGFloat(28 + ((screenSizeWidth - 150) * CGFloat(progessCal))), bottomConstant: 5, rightConstant: 0, widthConstant: 0, heightConstant: 0)
             lineCal.anchor(nil, left: boxCalView.leftAnchor, bottom: progressView.bottomAnchor, right: nil, topConstant: 0, leftConstant: CGFloat(38 + ((screenSizeWidth - 150) * CGFloat(progessCal))), bottomConstant: 0, rightConstant: 0, widthConstant: 2, heightConstant: 40)
            //calLabel.centerXAnchor.constraint(equalTo: boxCalView.centerXAnchor, constant: 30).isActive = true
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        print(sumCal)
//-----------------------------------------------------------------------------------------------------------------
                //Firebase
                        
                        let user = Auth.auth().currentUser
                        guard user != nil else { return }
                        let uid = user!.uid
                        
                        let db = Firestore.firestore()
                        
                        db.collection("users").whereField("uid", isEqualTo: uid)
                            .getDocuments() { (querySnapshot, err) in
                                if let err = err {
                                    print("Error getting documents: \(err)")
                                } else {
                                    db.collection("users").document(uid).collection("WeightBefore\(uid)").document()
                                    for document in querySnapshot!.documents {
                                        print("\(document.documentID) => \(document.data())")
                                        print(document.data()["FullName"] as! String)
                                        print(document.data()["Age"] as! Double)
                                        print(document.data()["Height"] as! Double)
                                        print(document.data()["GestationalAge"] as! Double)
                                        print(document.data()["WeightBefore"] as! Double)
                                        
                                        self.userFullName  = document.data()["FullName"] as! String
                                        
                                        //self.userWeight  = [54,52]
                                        self.userWeightBefore = document.data()["WeightBefore"] as! Double
                                        self.userHeight = document.data()["Height"] as! Double
                                        self.userAge = Int(document.data()["Age"] as! Double)
                                        self.userGestationalAge = Int(document.data()["GestationalAge"] as! Double)
                                        self.uerBloodSugar = [124,20]
                                        self.userCaloriesPerDay = 0.00
                                        
                    
                                    }
                                }
                        }
                        
        db.collection("users").document(uid).collection("Weights").o
                            .getDocuments() { (querySnapshot, err) in
                                if let err = err {
                                    print("Error getting documents: \(err)")
                                } else {
                                        for document in querySnapshot!.documents {
                                            //print("\(document.documentID) => \(document.data())")
                                            self.userWeight.insert(userWeights.init(WeightUpdate: document.data()["Weight"] as! Double, date: "\(Date.dateFromCustomString(customString: document.data()["date"] as! String))"), at: 0)
        //                                    self.userWeight.append(userWeights.init(WeightUpdate: document.data()["Weight"] as! Double, date: Date.dateFromCustomString(customString: document.data()["date"] as! String)))
                                            
                                            //print("\(document.data()["Weight"] as! Double)")
                                            print("\(document.data()["date"] as! String)")
                                            print("__________________________________________________________")
                                           
                                        }
                                }
                            }
                Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { (t) in
                    self.setDataUser()
                    self.UpdateUIProgress()
                }
                
//-----------------------------------------------------------------------------------------------------------------
           
        
      
    }
    override func viewDidAppear(_ animated: Bool) {
        Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { (t) in
            self.setDataUser()
            self.UpdateUIProgress()
        }
    }
    override func viewDidDisappear(_ animated: Bool) {
         progressView.progress = 0
         HomeViewController.updateCal = 0
         timer.invalidate()
     }
    @objc func nextPageProfile() {
       let settingsController = ProfileViewController()
        settingsController.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(settingsController, animated: true)
    }
    @objc func nextPage(_sender: UIButton) {
        if _sender.tag == 1 {
            let settingsController = BloodSugarViewController()
            settingsController.hidesBottomBarWhenPushed = true
             //settingsController.dataUser = dataUser
            navigationController?.pushViewController(settingsController, animated: true)
        }else {
            let settingsController = WeightViewController()
            settingsController.hidesBottomBarWhenPushed = true
            // settingsController.dataUser = userWeight
            navigationController?.pushViewController(settingsController, animated: true)
        }
    }
    @objc func drinkWater(_sender: UIButton) {
        if _sender.tag == 0 {
            water1Bool = !water1Bool
            if water1Bool == true {
                water1.backgroundColor = .blue
                water2.backgroundColor = .gray
                water3.backgroundColor = .gray
                water4.backgroundColor = .gray
                water5.backgroundColor = .gray
                water6.backgroundColor = .gray
            }else{
                water1.backgroundColor = .gray
                water2.backgroundColor = .gray
                water3.backgroundColor = .gray
                water4.backgroundColor = .gray
                water5.backgroundColor = .gray
                water6.backgroundColor = .gray
            }
            water2Bool = false
            water3Bool = false
            water4Bool = false
            water5Bool = false
            water6Bool = false
        }else if _sender.tag == 1 {
            water2Bool = !water2Bool
            if water2Bool == true {
                water1.backgroundColor = .blue
                water2.backgroundColor = .blue
                water3.backgroundColor = .gray
                water4.backgroundColor = .gray
                water5.backgroundColor = .gray
                water6.backgroundColor = .gray
            }else{
                water1.backgroundColor = .blue
                water2.backgroundColor = .gray
                water3.backgroundColor = .gray
                water4.backgroundColor = .gray
                water5.backgroundColor = .gray
                water6.backgroundColor = .gray
            }
            water2Bool = true
            water3Bool = false
            water4Bool = false
            water5Bool = false
            water6Bool = false
        }else if _sender.tag == 2 {
            water3Bool = !water3Bool
             if water3Bool == true {
                 water1.backgroundColor = .blue
                 water2.backgroundColor = .blue
                 water3.backgroundColor = .blue
                 water4.backgroundColor = .gray
                 water5.backgroundColor = .gray
                 water6.backgroundColor = .gray
             }else{
                 water1.backgroundColor = .blue
                 water2.backgroundColor = .blue
                 water3.backgroundColor = .gray
                 water4.backgroundColor = .gray
                 water5.backgroundColor = .gray
                 water6.backgroundColor = .gray
             }
            water1Bool = true
            water2Bool = true
            water4Bool = false
            water5Bool = false
            water6Bool = false
        }else if _sender.tag == 3 {
            water4Bool = !water4Bool
             if water4Bool == true {
                 water1.backgroundColor = .blue
                 water2.backgroundColor = .blue
                 water3.backgroundColor = .blue
                 water4.backgroundColor = .blue
                 water5.backgroundColor = .gray
                 water6.backgroundColor = .gray

             }else{
                 water1.backgroundColor = .blue
                 water2.backgroundColor = .blue
                 water3.backgroundColor = .blue
                 water4.backgroundColor = .gray
                 water5.backgroundColor = .gray
                 water6.backgroundColor = .gray
             }
            water1Bool = true
            water2Bool = true
            water3Bool = true
            water5Bool = false
            water6Bool = false
        }else if _sender.tag == 4 {
            water5Bool = !water5Bool
            if water5Bool == true {
                water1.backgroundColor = .blue
                water2.backgroundColor = .blue
                water3.backgroundColor = .blue
                water4.backgroundColor = .blue
                water5.backgroundColor = .blue
                water6.backgroundColor = .gray
            }else{
                water1.backgroundColor = .blue
                water2.backgroundColor = .blue
                water3.backgroundColor = .blue
                water4.backgroundColor = .blue
                water5.backgroundColor = .gray
                water6.backgroundColor = .gray
            }
            water1Bool = true
            water2Bool = true
            water3Bool = true
            water4Bool = true
            water6Bool = false
        }else if _sender.tag == 5 {
            water6Bool = !water6Bool
            if water6Bool == true {
                water1.backgroundColor = .blue
                water2.backgroundColor = .blue
                water3.backgroundColor = .blue
                water4.backgroundColor = .blue
                water5.backgroundColor = .blue
                water6.backgroundColor = .blue
            }else{
                water1.backgroundColor = .blue
                water2.backgroundColor = .blue
                water3.backgroundColor = .blue
                water4.backgroundColor = .blue
                water5.backgroundColor = .blue
                water6.backgroundColor = .gray
            }
            water1Bool = true
            water2Bool = true
            water3Bool = true
            water4Bool = true
            water5Bool = true
        }
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataMeal.count
       }
       
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellId", for: indexPath) as! mealCollectionViewCell
         let group = dataMeal[indexPath.row]
        cell.Title.text = group.name
        cell.titleImage.image = group.img
        return cell
       }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width , height: 220)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    @objc func nextPhotoView() {
        
        tabBarController?.selectedIndex = 2
        
        tabBarController?.tabBar.tintColor = .darkPink
        tabBarController?.tabBar.barTintColor = UIColor.black
        tabBarController?.tabBar.layer.masksToBounds = true
        tabBarController?.tabBar.isTranslucent = true
        tabBarController?.tabBar.barStyle = .black
        tabBarController?.tabBar.layer.cornerRadius = 20
        tabBarController?.tabBar.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        if let items = tabBarController?.tabBar.items {
            for item in items {
                item.title = nil
                item.imageInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
            }
        }
    }

    @objc func logoutView() {
            do {
                         try Auth.auth().signOut()
                         self.view.window?.rootViewController = UINavigationController(rootViewController: LoginViewController())
                         self.view.window?.makeKeyAndVisible()
                     } catch let error {
                         print("Failed to sign out with error..", error)
                     }
       }
    
}
