//
//  chatCollectionViewCell.swift
//  SweetMom
//
//  Created by kantapong on 31/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class chatCollectionViewCell: UICollectionViewCell {
    
    let screenSizeWidth: CGFloat = UIScreen.main.bounds.width
    
    let boxView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.2
        return view
    }()
    let imagHead: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "01")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        image.layer.cornerRadius = 8
        image.layer.maskedCorners = [.layerMinXMinYCorner /*top left corner*/, .layerMaxXMinYCorner /*top right corner*/]
        return image
    }()

    let name: UILabel = {
        let label = UILabel()
        label.text = "กันตพงศ์"
        label.textColor = .black
        label.font = UIFont.Opun(size: 18)
        label.numberOfLines = 0
        return label
    }()
    let educationTitle: UILabel = {
        let label = UILabel()
        label.text = "การศึกษา"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    let education: UILabel = {
        let label = UILabel()
        label.text = "กันตพงศ์"
        label.textColor = .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    let workTitle: UILabel = {
        let label = UILabel()
        label.text = "การอบรมและการทำงาน"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    let work: UILabel = {
        let label = UILabel()
        label.text = "กันตพงศ์"
        label.textColor = .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    let nextPage: UIButton = {
        let button = UIButton(type: .system)
        let gradientLayer = CAGradientLayer()
        button.frame = CGRect(x: 0, y: 0, width: 400, height: 40)
        gradientLayer.frame = button.frame
        gradientLayer.colors = [UIColor.lightPink.cgColor, UIColor.darkPink.cgColor]
        button.layer.insertSublayer(gradientLayer, at: 0)
        button.clipsToBounds = true
        button.layer.cornerRadius = 8
        button.setTitle("แชท", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 20)
        button.addTarget(self, action: #selector(ChatViewController.nextPage), for: .touchUpInside)
        return button
    }()
    
    override init(frame: CGRect) {
           super.init(frame: frame)
        addSubview(boxView)
        boxView.addSubview(name)
        boxView.addSubview(imagHead)
        boxView.addSubview(educationTitle)
        boxView.addSubview(education)
        boxView.addSubview(workTitle)
        boxView.addSubview(work)
        boxView.addSubview(nextPage)
        
        boxView.anchor(topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 40, leftConstant: 20, bottomConstant: 40, rightConstant: 20, widthConstant: 0, heightConstant: 0)
        
        imagHead.anchor(boxView.topAnchor, left: boxView.leftAnchor, bottom: nil, right: boxView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 80)
        
        name.anchor(imagHead.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        name.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
        educationTitle.anchor(name.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        educationTitle.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
        education.anchor(educationTitle.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth - 60, heightConstant: 0)
        education.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
        workTitle.anchor(education.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        workTitle.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
        work.anchor(workTitle.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth - 60, heightConstant: 0)
        work.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
        nextPage.anchor(nil, left: boxView.leftAnchor, bottom: boxView.bottomAnchor, right: boxView.rightAnchor, topConstant: 0, leftConstant: 60, bottomConstant: 25, rightConstant: 60, widthConstant: 0, heightConstant: 40)
       }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
