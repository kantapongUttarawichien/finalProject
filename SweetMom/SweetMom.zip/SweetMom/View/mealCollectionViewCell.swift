//
//  mealCollectionViewCell.swift
//  SweetMom
//
//  Created by kantapong on 8/2/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class mealCollectionViewCell: UICollectionViewCell {
    
     let boxView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.2
        view.layer.cornerRadius = 8
        return view
       }()
    
    
    let Title: UILabel = {
        let label = UILabel()
        label.text = "สวัสดีครับ"
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.numberOfLines = 0
        return label
    }()
    
    let addBloodButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .lightPink
        button.layer.cornerRadius = 8
        button.setTitle("เพิ่มอาหาร", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 12)
        button.setImage(UIImage(named: "iconButton"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.tintColor = UIColor.whiteAlpha(alpha: 0.8)
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: -5, bottom: 10, right: 0)
        button.addTarget(self, action: #selector(nextPage), for: .touchUpInside)
        button.tag = 1
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(boxView)
        boxView.addSubview(Title)
        
        boxView.anchor(topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 0, leftConstant: 25, bottomConstant: 0, rightConstant: 25, widthConstant: 0, heightConstant: 0)
        
       Title.anchor(boxView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        Title.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
          
    }
       
    required init?(coder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
    }
    
}
