//
//  mealCollectionViewCell.swift
//  SweetMom
//
//  Created by kantapong on 8/2/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class mealCollectionViewCell: UICollectionViewCell {
    
    lazy var boxView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.2
        view.layer.cornerRadius = 8
        return view
    }()
    
    lazy var boxTitle: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    lazy var titleImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconMeal_01")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()

    lazy var Title: UILabel = {
        let label = UILabel()
        label.text = "สวัสดีครับ"
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var addFoodButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .lightPink
        button.layer.cornerRadius = 8
        button.setTitle("เพิ่มอาหาร", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 12)
        button.setImage(UIImage(named: "iconButton"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.tintColor = UIColor.whiteAlpha(alpha: 0.8)
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: -5, bottom: 10, right: 0)
        button.addTarget(self, action: #selector(HomeViewController.nextPhotoView), for: .touchUpInside)
        button.tag = 1
        return button
    }()
    lazy var space: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    lazy var historyFoodButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = .lightPink
        button.layer.cornerRadius = 8
        button.setTitle("History", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 12)
        button.setImage(UIImage(named: "iconButton"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.tintColor = UIColor.whiteAlpha(alpha: 0.8)
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: -5, bottom: 10, right: 0)
        //button.addTarget(self, action: #selector(HomeViewController.nextPhotoView), for: .touchUpInside)
        button.tag = 1
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(boxView)
       // boxView.addSubview(boxTitle)
        boxView.addSubview(Title)
        boxView.addSubview(titleImage)
        boxView.addSubview(addFoodButton)
        boxView.addSubview(space)
        boxView.addSubview(historyFoodButton)
        
        boxView.anchor(topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 30, leftConstant: 25, bottomConstant: 30, rightConstant: 25, widthConstant: 0, heightConstant: 0)
        
//        boxTitle.anchor(boxView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
//        boxTitle.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
//
        Title.anchor(boxView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 15, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        Title.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
        titleImage.anchor(boxView.topAnchor, left: nil, bottom: nil, right: Title.leftAnchor, topConstant: -40, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 100, heightConstant: 100)
        
        addFoodButton.anchor(nil, left: boxView.leftAnchor, bottom: boxView.bottomAnchor, right: space.leftAnchor, topConstant: 0, leftConstant: 15, bottomConstant: 15, rightConstant: 0, widthConstant: 0, heightConstant: 40)
        
        space.anchor(nil, left: nil, bottom: boxView.bottomAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 15, rightConstant: 0, widthConstant: 20, heightConstant: 10)
        space.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
        historyFoodButton.anchor(nil, left: space.rightAnchor, bottom: boxView.bottomAnchor, right: boxView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 15, rightConstant: 15, widthConstant: 0, heightConstant: 40)
          
    }
       
    required init?(coder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
    }
    
}
