//
//  LoginViewController.swift
//  SweetMom
//
//  Created by kantapong on 14/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController, UITextFieldDelegate{

    let backgroundView: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "background")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()
    
    let logoImage: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "Logo")
        image.contentMode =  .scaleAspectFit
        image.layer.masksToBounds = true
        return image
    }()

    let backgroundUIView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        return view
    }()
    
    let headUIView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 60))
        let gradient = CAGradientLayer()
        view.clipsToBounds = true
        view.layer.maskedCorners = [.layerMinXMinYCorner /*top left corner*/, .layerMaxXMinYCorner /*top right corner*/]
        gradient.frame = view.bounds
        gradient.colors = [UIColor.darkPink.cgColor, UIColor.lightPink.cgColor]
        view.layer.cornerRadius = 8
        gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        view.layer.addSublayer(gradient)
        return view
    }()
    
    let loginTextLabel: UILabel = {
        let label = UILabel()
        label.text = "เข้าสู่ระบบ"
        label.textColor = .white
        label.font = UIFont.Opun(size: 20)
        label.numberOfLines = 0
        return label
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    let emailView: UIView = {
        let view = UIView()
        return view
    }()
    
    let emailIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconEmail")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
   
    let emailTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "อีเมล", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .emailAddress
        textField.leftViewMode = UITextField.ViewMode.always
        //textField.addTarget(self, action: #selector(handelemailCheckValid), for: .editingChanged)
        return textField
    }()
    
    let emailbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    let passwordView: UIView = {
        let view = UIView()
        return view
    }()
    
    let passwordIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconPassword")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
    
    let passwordTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "รหัสผ่าน", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.isSecureTextEntry = true
        textField.leftViewMode = UITextField.ViewMode.always
        //textField.addTarget(self, action: #selector(handlepasswordCheckValid), for: .editingChanged)
        return textField
    }()
    
    let passwordbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()

//-----------------------------------------------------------------------------------------------------------------

    let LoginButton: UIButton = {
        let button = UIButton(type: .system)
        let gradientLayer = CAGradientLayer()
        button.frame = CGRect(x: 0, y: 0, width: 400, height: 50)
        gradientLayer.frame = button.frame
        gradientLayer.colors = [UIColor.lightPink.cgColor, UIColor.darkPink.cgColor]
        button.layer.insertSublayer(gradientLayer, at: 0)
        button.clipsToBounds = true
        button.layer.cornerRadius = 8
        button.setTitle("Login", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 20)
        button.addTarget(self, action: #selector(loginaddress), for: .touchUpInside)
        return button
    }()
    
    let signUpButton: UIButton = {
        let button = UIButton(type: .system)
        //button.backgroundColor = .red
        button.setTitle("Sign Up", for: .normal)
        button.setTitleColor(.darkPink, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 16)
        button.addTarget(self, action: #selector(nextPage), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        navigationController?.navigationBar.shadowImage = UIImage()
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
//-----------------------------------------------------------------------------------------------------------------
        
        let stacView = UIStackView(arrangedSubviews: [emailView,passwordView])
        stacView.distribution = .fillEqually
        stacView.spacing = 25
        stacView.axis = .vertical
        emailTextField.delegate = self
        passwordTextField.delegate = self
        
//-----------------------------------------------------------------------------------------------------------------
        
        view.addSubview(backgroundView)
        view.addSubview(logoImage)
        view.addSubview(backgroundUIView)
        backgroundUIView.addSubview(headUIView)
        headUIView.addSubview(loginTextLabel)
        backgroundUIView.addSubview(stacView)
        backgroundUIView.addSubview(LoginButton)
        backgroundUIView.addSubview(signUpButton)
        
        backgroundView.anchor(view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        logoImage.anchor(view.safeAreaLayoutGuide.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 200)
        logoImage.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        backgroundUIView.anchor(logoImage.bottomAnchor, left: backgroundView.leftAnchor, bottom: nil, right: backgroundView.rightAnchor, topConstant: 10, leftConstant: 30, bottomConstant: 0, rightConstant: 30, widthConstant: 0, heightConstant: 350)
       // backgroundUIView.centerYAnchor.constraint(equalTo: backgroundView.centerYAnchor,constant: 100).isActive = true
        
        headUIView.anchor(backgroundUIView.topAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 60)
        
        loginTextLabel.anchor(headUIView.topAnchor, left: headUIView.leftAnchor, bottom: nil, right: nil, topConstant: 10, leftConstant: 20, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        stacView.anchor(headUIView.bottomAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 30, leftConstant: 20, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 100)
        
//-----------------------------------------------------------------------------------------------------------------
        
        emailView.addSubview(emailIcon)
        emailView.addSubview(emailTextField)
        emailView.addSubview(emailbuttonline)
        
        emailIcon.anchor(emailView.topAnchor, left: emailView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
               
        emailTextField.anchor(emailView.topAnchor, left: emailIcon.leftAnchor, bottom: nil, right: emailView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
               
        emailbuttonline.anchor(nil, left: emailView.leftAnchor, bottom: emailView.bottomAnchor, right: emailView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
       
//-----------------------------------------------------------------------------------------------------------------
        
        passwordView.addSubview(passwordIcon)
        passwordView.addSubview(passwordTextField)
        passwordView.addSubview(passwordbuttonline)
        
        passwordIcon.anchor(passwordView.topAnchor, left: passwordView.leftAnchor, bottom: nil, right: nil, topConstant: 2, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
        
        passwordTextField.anchor(passwordView.topAnchor, left: passwordIcon.leftAnchor, bottom: nil, right: passwordView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
        
        passwordbuttonline.anchor(passwordTextField.bottomAnchor, left: passwordView.leftAnchor, bottom: nil, right: passwordView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)

//-----------------------------------------------------------------------------------------------------------------
        
        LoginButton.anchor(stacView.bottomAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 30, leftConstant: 50, bottomConstant: 0, rightConstant: 50, widthConstant: 0, heightConstant: 50)
        
        signUpButton.anchor(LoginButton.bottomAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 10, leftConstant: 50, bottomConstant: 0, rightConstant: 50, widthConstant: 0, heightConstant: 50)
    }

//-----------------------------------------------------------------------------------------------------------------
    @objc func loginaddress() {
        guard let email = emailTextField.text, let password = passwordTextField.text else{ return }

        Auth.auth().signIn(withEmail: email, password: password) { [weak self] result, error in
//        guard let strongSelf = self else { return }
            if error != nil {
               
            }
            else {
                self!.view.window?.rootViewController = TabBarController()
                self!.view.window?.makeKeyAndVisible()
            }
        }
    }
    @objc func nextPage(){
        
        let settingsController = registerViewController()
        navigationController?.pushViewController(settingsController, animated: true)
        
    }
//-----------------------------------------------------------------------------------------------------------------
    
    @objc func keyboardWillShow(notification: NSNotification) {
          if self.view.frame.origin.y == 0 {
              self.view.frame.origin.y -= 100
                        //keyboardSize.height
          }
      }
    @objc func keyboardWillHide(notification: NSNotification) {
          if self.view.frame.origin.y != 0 {
              self.view.frame.origin.y = 0
          }
      }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    
    }
    
}
