//
//  registerViewController.swift
//  SweetMom
//
//  Created by kantapong on 18/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import FirebaseFirestore
import FirebaseAuth

class registerViewController: UIViewController, UITextFieldDelegate {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
      return .darkContent
    }
    var BMI = 0.00
    static var page = 1
    var Field01 = 60
    var Field02 = 60
    var Field03 = 60
    var Field04 = 60
    var dataUser : User?
    let screenSizeWidth: CGFloat = UIScreen.main.bounds.width
    let screenSizeHeight: CGFloat = UIScreen.main.bounds.height
    
    static var userFullName : String = ""
    static var userEmail : String = ""
    static var userPassword : String = ""
    static var userWeight : Double = 0.00
    static var userWeightBefore : Double = 0.00
    static var userHeight : Double = 0.00
    static var userAge : Int = 0
    static var userGestationalAge : Int = 0
    static var uerBloodSugar : Double = 0.00
    
    lazy var stacView: UIStackView = {
        let stac = UIStackView()
        return stac
    }()
    
    lazy var stacViewPageControll: UIStackView = {
        let stac = UIStackView()
        return stac
    }()

    lazy var backgroundView: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "backgroundLogin")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()
    
    lazy var viewScroll: UIScrollView = {
        let view = UIScrollView()
        view.showsVerticalScrollIndicator = false
        return view
    }()
    
    lazy var iconRegister: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconRegister01")
        image.contentMode =  .scaleAspectFit
        image.layer.masksToBounds = true
        return image
    }()
    
    lazy var backgroundUIView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        return view
    }()
    
    lazy var backgroundUIViewFooter: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    lazy var nameView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var nameIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconProfile_Color")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var nameTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "ชื่อ", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageOne), for: .editingChanged)
        return textField
    }()
           
    lazy var namebuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------
           
    lazy var emailView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var emailIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconProfile_Color")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var emailTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "อีเมล", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .emailAddress
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageOne), for: .editingChanged)
        return textField
    }()
           
    lazy var emailbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()

//-----------------------------------------------------------------------------------------------------------------

    lazy var passwordView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var passwordIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconPassword")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var passwordTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "รหัสผ่าน", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.isSecureTextEntry = true
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageOne), for: .editingChanged)
        return textField
    }()
           
    lazy var passwordbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    lazy var passwordConfirmView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var passwordConfirmIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconPassword")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var passwordConfirmTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "ยืนยันรหัสผ่าน", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.isSecureTextEntry = true
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageOne), for: .editingChanged)
        return textField
    }()
           
    lazy var passwordConfirmbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
        
//-----------------------------------------------------------------------------------------------------------------
    
    lazy var viewPageTwo: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var titleBMI: UILabel = {
        let label = UILabel()
        label.text = "ดัชนีมวลกาย(BMI)"
        label.textColor = .black
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    lazy var boxNumber: UIView = {
        let view = UIView()
        view.backgroundColor = .palePink
        view.layer.cornerRadius = 8
        return view
    }()
    
    lazy var Number: UILabel = {
        let label = UILabel()
        label.text = ""
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 18)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    lazy var textOput: UILabel = {
        let label = UILabel()
        label.text = "ผล :"
        label.textColor = .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var textOputResults: UILabel = {
        let label = UILabel()
        label.text = ""
        label.textColor = .green
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var textOput2: UILabel = {
        let label = UILabel()
        label.text = "ภาวะเสี่ยงต่อโรค :"
        label.textColor = .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var textOputResults2: UILabel = {
        let label = UILabel()
        label.text = ""
        label.textColor = .green
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var OputResultsbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()

//-----------------------------------------------------------------------------------------------------------------

    lazy var weightView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var weightIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconRegister")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var weightTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "น้ำหนัก(ปัจจุบัน)", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .asciiCapableNumberPad
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageTwo), for: .editingChanged)
        return textField
    }()
           
    lazy var weightbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
   
//-----------------------------------------------------------------------------------------------------------------

    lazy var heightView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var heightIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconRegister")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var heightTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "ส่วนสูง", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .asciiCapableNumberPad
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageTwo), for: .editingChanged)
        return textField
    }()
           
    lazy var heightbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()

//-----------------------------------------------------------------------------------------------------------------

    lazy var weightBeforeView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var weightBeforeIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconRegister")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var weightBeforeTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "น้ำหนัก(ก่อนตั้งครรภ์)", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .asciiCapableNumberPad
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageTwo), for: .editingChanged)
        return textField
    }()
           
    lazy var weightBeforebuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
        
//-----------------------------------------------------------------------------------------------------------------
          
    lazy var ageView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var ageIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconRegister")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var ageTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "อายุ", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .asciiCapableNumberPad
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageThree), for: .editingChanged)
        return textField
    }()
           
    lazy var agebuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    lazy var gestationalAgeView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var gestationalAgeIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconRegister")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var gestationalAgeTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "อายุครรภ์(สัปดาห์)", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .asciiCapableNumberPad
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageThree), for: .editingChanged)
        return textField
    }()
           
    lazy var gestationalAgebuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    lazy var bloodSugarView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var bloodSugarIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconRegister")//?.withRenderingMode(.alwaysTemplate)
        image.contentMode = .scaleAspectFit
        //image.tintColor = UIColor.whiteAlpha(alpha: 0.5)
        return image
    }()
        
    lazy var bloodSugarTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "ระดับน้ำตาลในเลือด(ล่าสุด)", attributes: [NSAttributedString.Key.font : UIFont.Opun(size: 14), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.3)])
        textField.textColor = UIColor.blackAlpha(alpha: 0.7)
        textField.font = UIFont.Opun(size: 14)
        textField.keyboardType = .asciiCapableNumberPad
        textField.leftViewMode = UITextField.ViewMode.always
        textField.addTarget(self, action: #selector(CheckValidPageFour), for: .editingChanged)
        return textField
    }()
           
    lazy var bloodSugarbuttonline: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blackAlpha(alpha: 0.1)
        return view
    }()

//-----------------------------------------------------------------------------------------------------------------
//PageControll
    
    lazy var pageControllOne: UIView = {
        let view = UIView()
       view.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1)
        view.layer.cornerRadius = 5
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.white.cgColor
        return view
    }()
    
    lazy var pageControllTwo: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.5)
        view.layer.cornerRadius = 5
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.white.cgColor
        return view
    }()
    
    lazy var pageControllThree: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.5)
        view.layer.cornerRadius = 5
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.white.cgColor
        return view
    }()
    
    lazy var pageControllFour: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.5)
        view.layer.cornerRadius = 5
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.white.cgColor
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    lazy var textError: UILabel = {
        let label = UILabel()
        label.text = nil
        label.textColor = .red
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    lazy var LoginButton: UIButton = {
        var button = UIButton(type: .system)
        let gradientLayer = CAGradientLayer()
        button.frame = CGRect(x: 0, y: 0, width: 400, height: 70)
        gradientLayer.frame = button.frame
        gradientLayer.colors = [UIColor.lightPink.cgColor, UIColor.darkPink.cgColor]
        button.layer.insertSublayer(gradientLayer, at: 0)
        button.clipsToBounds = true
        button.layer.cornerRadius = 8
        button.setTitle("ถัดไป", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 20)
        button.addTarget(self, action: #selector(handleDone), for: .touchUpInside)
        button.tag = 1
        button.isEnabled = false
        return button
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(sender:)))
        view.addGestureRecognizer(tap)
        navigationItem.title = "สมัครสมาชิก"
         
        navigationItem.hidesBackButton = true
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font:UIFont.Opun(size: 20), NSAttributedString.Key.foregroundColor:UIColor.black]
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        navigationController?.navigationBar.shadowImage = UIImage()
        let backButton = UIBarButtonItem(image: UIImage(named: "iconBack")?.withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(handleBack))
        navigationItem.leftBarButtonItem = backButton
        
//-----------------------------------------------------------------------------------------------------------------

        view.backgroundColor = .white
        stacView = UIStackView(arrangedSubviews: [nameView,emailView,passwordView,passwordConfirmView,weightView,heightView,weightBeforeView,ageView,gestationalAgeView,bloodSugarView])
        stacView.distribution = .fillEqually
        stacView.spacing = 25
        stacView.axis = .vertical
        
        stacViewPageControll = UIStackView(arrangedSubviews: [pageControllOne,pageControllTwo,pageControllThree,pageControllFour])
        stacViewPageControll.distribution = .fillEqually
        stacViewPageControll.spacing = 10
        stacViewPageControll.axis = .horizontal

        self.nameTextField.delegate = self
        self.emailTextField.delegate = self
        self.passwordTextField.delegate = self
        self.passwordConfirmTextField.delegate = self
        
        self.weightTextField.delegate = self
        self.heightTextField.delegate = self
        self.weightBeforeTextField.delegate = self
        self.ageTextField.delegate = self
        self.gestationalAgeTextField.delegate = self
        self.bloodSugarTextField.delegate = self
        
        view.addSubview(backgroundView)
        view.addSubview(backgroundUIViewFooter)
        view.addSubview(viewScroll)
        viewScroll.addSubview(iconRegister)
        viewScroll.addSubview(stacViewPageControll)
        viewScroll.addSubview(backgroundUIView)
//-----------------------------------------------------------------------------------------------------------------
        //pageTwo
        backgroundUIView.addSubview(viewPageTwo)
        viewPageTwo.addSubview(titleBMI)
        viewPageTwo.addSubview(boxNumber)
        boxNumber.addSubview(Number)
        
//        let stacViewPageTwoControll = UIStackView(arrangedSubviews: [textOput,textOputResults,textOputResults2,textOput2])
//        stacViewPageControll.distribution = .fillEqually
//        stacViewPageControll.spacing = 25
//        stacViewPageControll.axis = .vertical
//
        viewPageTwo.addSubview(textOput)
        viewPageTwo.addSubview(textOput2)
        viewPageTwo.addSubview(textOputResults)
        viewPageTwo.addSubview(textOputResults2)
        viewPageTwo.addSubview(OputResultsbuttonline)
//-----------------------------------------------------------------------------------------------------------------
        backgroundUIView.addSubview(stacView)
        backgroundUIView.addSubview(textError)
        backgroundUIView.addSubview(LoginButton)
        
        backgroundView.anchor(view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        viewScroll.anchor(view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        iconRegister.anchor(viewScroll.topAnchor, left: nil, bottom:nil, right: nil, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth/2, heightConstant: screenSizeWidth/2-20)
        iconRegister.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        stacViewPageControll.anchor(iconRegister.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 70, heightConstant: 10)
        stacViewPageControll.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        backgroundUIView.anchor(stacViewPageControll.bottomAnchor, left: view.leftAnchor, bottom: viewScroll.bottomAnchor, right: view.rightAnchor, topConstant: 30, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth, heightConstant: screenSizeHeight/2 + 140)
        
        backgroundUIViewFooter.anchor(nil, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth, heightConstant: 220)
        
//-----------------------------------------------------------------------------------------------------------------
//pageTwo
        
        viewPageTwo.anchor(backgroundUIView.topAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 0, leftConstant: 40, bottomConstant: 0, rightConstant: 40, widthConstant: 0, heightConstant: 0 )
        
        titleBMI.anchor(viewPageTwo.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        titleBMI.centerXAnchor.constraint(equalTo: viewPageTwo.centerXAnchor).isActive = true
        
        boxNumber.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 15, rightConstant: 0, widthConstant: 80, heightConstant: 50)
        boxNumber.centerXAnchor.constraint(equalTo: viewPageTwo.centerXAnchor, constant: -90).isActive = true
        boxNumber.centerYAnchor.constraint(equalTo: viewPageTwo.centerYAnchor, constant: 15).isActive = true
        //boxNumber.heightAnchor.constraint(lessThanOrEqualToConstant: 60).isActive = true
        
        Number.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        Number.centerXAnchor.constraint(equalTo: boxNumber.centerXAnchor).isActive = true
        Number.centerYAnchor.constraint(equalTo: boxNumber.centerYAnchor).isActive = true
        
        textOput.anchor(boxNumber.topAnchor, left: boxNumber.rightAnchor, bottom: nil, right: nil, topConstant: 2, leftConstant: 10, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        textOputResults.anchor(boxNumber.topAnchor, left: textOput.rightAnchor, bottom: nil, right: nil, topConstant: -3, leftConstant: 5, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        textOput2.anchor(textOput.bottomAnchor, left: boxNumber.rightAnchor, bottom: nil, right: nil, topConstant: 0, leftConstant: 10, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        textOputResults2.anchor(textOput.bottomAnchor, left: textOput2.rightAnchor, bottom: nil, right: nil, topConstant: -4, leftConstant: 5, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        OputResultsbuttonline.anchor(nil, left: view.leftAnchor, bottom: viewPageTwo.bottomAnchor, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------

        stacView.anchor(viewPageTwo.bottomAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 40,  leftConstant: 40, bottomConstant: 0, rightConstant: 40, widthConstant: 0, heightConstant: CGFloat(Field01+Field02+Field03+Field04))
        
        textError.anchor(stacView.bottomAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 10, leftConstant: 40, bottomConstant: 0, rightConstant: 40, widthConstant: 0, heightConstant: 0)
     
        LoginButton.anchor(textError.bottomAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 20, leftConstant: 80, bottomConstant: 0, rightConstant: 80, widthConstant: 0, heightConstant: 50)
        
//-----------------------------------------------------------------------------------------------------------------
        
        emailView.addSubview(emailIcon)
        emailView.addSubview(emailTextField)
        emailView.addSubview(emailbuttonline)
        
        emailIcon.anchor(emailView.topAnchor, left: emailView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
               
        emailTextField.anchor(emailView.topAnchor, left: emailIcon.leftAnchor, bottom: nil, right: emailView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
               
        emailbuttonline.anchor(nil, left: emailView.leftAnchor, bottom: emailView.bottomAnchor, right: emailView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------
        
        nameView.addSubview(nameIcon)
        nameView.addSubview(nameTextField)
        nameView.addSubview(namebuttonline)
        
        nameIcon.anchor(nameView.topAnchor, left: nameView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
               
        nameTextField.anchor(nameView.topAnchor, left: nameIcon.leftAnchor, bottom: nil, right: emailView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
               
        namebuttonline.anchor(nameTextField.bottomAnchor, left: nameView.leftAnchor, bottom: nil, right: nameView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------
      
        passwordView.addSubview(passwordIcon)
        passwordView.addSubview(passwordTextField)
        passwordView.addSubview(passwordbuttonline)
                
        passwordIcon.anchor(passwordView.topAnchor, left: passwordView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                       
        passwordTextField.anchor(passwordView.topAnchor, left: passwordIcon.leftAnchor, bottom: nil, right: emailView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                       
        passwordbuttonline.anchor(passwordTextField.bottomAnchor, left: passwordView.leftAnchor, bottom: nil, right: passwordView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
                
//-----------------------------------------------------------------------------------------------------------------
       
        passwordConfirmView.addSubview(passwordConfirmIcon)
        passwordConfirmView.addSubview(passwordConfirmTextField)
        passwordConfirmView.addSubview(passwordConfirmbuttonline)
                        
        passwordConfirmIcon.anchor(passwordConfirmView.topAnchor, left: passwordConfirmView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                               
        passwordConfirmTextField.anchor(passwordConfirmView.topAnchor, left: passwordIcon.leftAnchor, bottom: nil, right: passwordConfirmView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                               
        passwordConfirmbuttonline.anchor(passwordConfirmTextField.bottomAnchor, left: passwordConfirmView.leftAnchor, bottom: nil, right: passwordConfirmView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
                        
//-----------------------------------------------------------------------------------------------------------------

        weightView.addSubview(weightIcon)
        weightView.addSubview(weightTextField)
        weightView.addSubview(weightbuttonline)
                        
        weightIcon.anchor(weightView.topAnchor, left: weightView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                               
        weightTextField.anchor(weightView.topAnchor, left: weightIcon.leftAnchor, bottom: nil, right: weightView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                               
        weightbuttonline.anchor(weightTextField.bottomAnchor, left: weightView.leftAnchor, bottom: nil, right: weightView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------

        heightView.addSubview(heightIcon)
        heightView.addSubview(heightTextField)
        heightView.addSubview(heightbuttonline)
                        
        heightIcon.anchor(heightView.topAnchor, left: heightView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                               
        heightTextField.anchor(heightView.topAnchor, left: heightIcon.leftAnchor, bottom: nil, right: heightView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                               
        heightbuttonline.anchor(heightTextField.bottomAnchor, left: heightView.leftAnchor, bottom: nil, right: heightView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------
       
        weightBeforeView.addSubview(weightBeforeIcon)
        weightBeforeView.addSubview(weightBeforeTextField)
        weightBeforeView.addSubview(weightBeforebuttonline)
                        
        weightBeforeIcon.anchor(weightBeforeView.topAnchor, left: weightBeforeView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                               
        weightBeforeTextField.anchor(weightBeforeView.topAnchor, left: weightBeforeIcon.leftAnchor, bottom: nil, right: weightBeforeView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                               
        weightBeforebuttonline.anchor(weightBeforeTextField.bottomAnchor, left: weightBeforeView.leftAnchor, bottom: nil, right: weightBeforeView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
        
//-----------------------------------------------------------------------------------------------------------------

        ageView.addSubview(ageIcon)
        ageView.addSubview(ageTextField)
        ageView.addSubview(agebuttonline)
                        
        ageIcon.anchor(ageView.topAnchor, left: ageView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                               
        ageTextField.anchor(ageView.topAnchor, left: ageIcon.leftAnchor, bottom: nil, right: ageView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                               
        agebuttonline.anchor(ageTextField.bottomAnchor, left: ageView.leftAnchor, bottom: nil, right: ageView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------

        gestationalAgeView.addSubview(gestationalAgeIcon)
        gestationalAgeView.addSubview(gestationalAgeTextField)
        gestationalAgeView.addSubview(gestationalAgebuttonline)
                        
        gestationalAgeIcon.anchor(gestationalAgeView.topAnchor, left: gestationalAgeView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                               
        gestationalAgeTextField.anchor(gestationalAgeView.topAnchor, left: gestationalAgeIcon.leftAnchor, bottom: nil, right: gestationalAgeView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                               
        gestationalAgebuttonline.anchor(gestationalAgeTextField.bottomAnchor, left: gestationalAgeView.leftAnchor, bottom: nil, right: gestationalAgeView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
//-----------------------------------------------------------------------------------------------------------------

        bloodSugarView.addSubview(bloodSugarIcon)
        bloodSugarView.addSubview(bloodSugarTextField)
        bloodSugarView.addSubview(bloodSugarbuttonline)
                        
        bloodSugarIcon.anchor(bloodSugarView.topAnchor, left: bloodSugarView.leftAnchor, bottom: nil, right: nil, topConstant: 3, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 24, heightConstant: 24)
                               
        bloodSugarTextField.anchor(bloodSugarView.topAnchor, left: bloodSugarIcon.leftAnchor, bottom: nil, right: ageView.rightAnchor, topConstant: 0, leftConstant: 35, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
                               
        bloodSugarbuttonline.anchor(bloodSugarTextField.bottomAnchor, left: bloodSugarView.leftAnchor, bottom: nil, right: bloodSugarView.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1.5)
        
        LoginButton.isEnabled = false
        LoginButton.setTitleColor(.whiteAlpha(alpha: 0.5), for: .normal)
        
//-----------------------------------------------------------------------------------------------------------------
        
        viewPageTwo.isHidden = true
        titleBMI.isHidden = true
        boxNumber.isHidden = true
        Number.isHidden = true
        textOput.isHidden = true
        textOputResults.isHidden = true
        textOput2.isHidden = true
        textOputResults2.isHidden = true
        OputResultsbuttonline.isHidden = true
        // Do any additional setup after loading the view.
        
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
       
    }
   
    @objc func handleBack() {
       
        registerViewController.page -= 1
        navigationController?.popViewController(animated: true)
    }
    
    func isValidEmail(email:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: email)
    }
    
    @objc func CheckValidPageOne() {
        guard let name = nameTextField.text, let email = emailTextField.text, let password = passwordTextField.text, let confirmpassword = passwordConfirmTextField.text else {return}
        
        let emailValid = isValidEmail(email: email)
        
        if name != "" && email != "" && password != "" && confirmpassword != "" && password == confirmpassword && emailValid {
            LoginButton.isEnabled = true
            LoginButton.setTitleColor(.whiteAlpha(alpha: 1), for: .normal)
        }else{
            LoginButton.isEnabled = false
            LoginButton.setTitleColor(.whiteAlpha(alpha: 0.5), for: .normal)
        
        }
    }
    
    @objc func CheckValidPageTwo() {
         guard let height = heightTextField.text, let weight =  weightTextField.text, let weightbefore = weightBeforeTextField.text else {return}
        
        if height != "" && weight != "" && weightbefore != "" {
            
            let heights = (height as NSString).doubleValue
            let weightbefores = (weightbefore as NSString).doubleValue

            BMI = weightbefores / ((heights / 100.00) * (heights / 100))
            Number.text = "\(Int(BMI))"
            if BMI >= 0 && BMI <= 20.99 {
                textOputResults.text = "น้ำหนักน้อย"
                textOputResults2.text = "มากกว่าคนปกติ"
                
            }else  if BMI >= 21 && BMI <= 26 {
                textOputResults.text = "ปกติ"
                textOputResults2.text = "เท่าคนปกติ"
                
            }else{
                textOputResults.text = "น้ำหนักเกิน"
                textOputResults2.text = "อันตราย"
            }
            
            LoginButton.isEnabled = true
            LoginButton.setTitleColor(.whiteAlpha(alpha: 1), for: .normal)
            
        }else{
            LoginButton.isEnabled = false
            LoginButton.setTitleColor(.whiteAlpha(alpha: 0.5), for: .normal)
        
        }
        
    }
    
    @objc func CheckValidPageThree() {
           guard let age = ageTextField.text, let gestationalAge = gestationalAgeTextField.text else {return}
           
           if age != "" && gestationalAge != "" {
               LoginButton.isEnabled = true
               LoginButton.setTitleColor(.whiteAlpha(alpha: 1), for: .normal)
           }else{
               LoginButton.isEnabled = false
               LoginButton.setTitleColor(.whiteAlpha(alpha: 0.5), for: .normal)
           
           }
       }
    
    @objc func CheckValidPageFour() {
        guard let bloodsugar = bloodSugarTextField.text else {return}
        
        if bloodsugar != "" {
            LoginButton.isEnabled = true
            LoginButton.setTitleColor(.whiteAlpha(alpha: 1), for: .normal)
        }else{
            LoginButton.isEnabled = false
            LoginButton.setTitleColor(.whiteAlpha(alpha: 0.5), for: .normal)
        
        }
    }
    
    @objc func handleDone(_sender: UIButton){
        
        if registerViewController.page == 1 {
            guard let name = nameTextField.text, let email = emailTextField.text, let password = passwordTextField.text else {return}
                
                registerViewController.userFullName = name
                registerViewController.userEmail = email
                registerViewController.userPassword = password
                registerViewController.page += 1
                self.navigationController?.pushViewController(registerViewController(), animated:true)
            
        }else if registerViewController.page == 2 {
            guard let height = heightTextField.text, let weight =  weightTextField.text, let weightbefore = weightBeforeTextField.text else {return}
            
                let heights = (height as NSString).doubleValue
                let weightbefores = (weightbefore as NSString).doubleValue
                let weights = (weight as NSString).doubleValue
            
                registerViewController.userWeight = weights
                registerViewController.userWeightBefore = weightbefores
                registerViewController.userHeight = heights
                registerViewController.page += 1
                self.navigationController?.pushViewController(registerViewController(), animated:true)
            
        }else if registerViewController.page == 3 {
            guard let age = ageTextField.text, let gestationalAge = gestationalAgeTextField.text else {return}
            
                let gestationalAges = (gestationalAge as NSString).doubleValue
                let ages = (age as NSString).doubleValue
            
                registerViewController.userGestationalAge = Int(gestationalAges)
                registerViewController.userAge = Int(ages)
                registerViewController.page += 1
                self.navigationController?.pushViewController(registerViewController(), animated:true)
            
        }else if registerViewController.page == 4 {
            guard let bloodsugar = bloodSugarTextField.text else {return}
            
                let bloodsugars = (bloodsugar as NSString).doubleValue
                registerViewController.uerBloodSugar = bloodsugars
                Auth.auth().createUser(withEmail: registerViewController.userEmail, password: registerViewController.userPassword) { authResult, err in
                    if err != nil {
                        self.textError.text = err!.localizedDescription
                        // There was an error creating the user
                        //self.showError("Error creating user")
                    }else {
                        let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                        changeRequest?.displayName = registerViewController.userFullName

                        changeRequest?.commitChanges { (error) in
                            if error == nil {

                                let db = Firestore.firestore()
                                db.collection("users").document(authResult!.user.uid).setData([
                                    "FullName" : registerViewController.userFullName,
                                    "Age" : registerViewController.userAge,
                                    "GestationalAge" : registerViewController.userGestationalAge,
                                    "Height" : registerViewController.userHeight,
                                    "WeightBefore" : registerViewController.userWeightBefore,
                                    "uid" : authResult!.user.uid]){(error) in
                                    
                                    if error != nil {
                                        // Show error message
                                        self.textError.text = error!.localizedDescription
                                        print("Error saving user data")
                                    }else {
                                db.collection("users").document(authResult!.user.uid).collection("Weights").document().setData([
                                    "Weight": registerViewController.userWeight,
                                    "date": "\(Date.dateFromCustomString(customString: "\(Date())"))"]){(error) in
                                        if error != nil {
                                            // Show error message
                                            self.textError.text = error!.localizedDescription
                                            print("Error saving user data")
                                        }else {
                                        db.collection("users").document(authResult!.user.uid).collection("BloodSugars").document().setData([
                                            "bloodSugar": registerViewController.uerBloodSugar,
                                            "date": "\(Date.dateFromCustomString(customString: "\(Date())"))"]){(error) in
                                                if error != nil {
                                                    // Show error message
                                                    self.textError.text = error!.localizedDescription
                                                    print("Error saving user data")
                                                }else {
                                                    if self.textError.text != nil {
                                                        self.backgroundUIView.anchor(self.stacViewPageControll.bottomAnchor, left: self.view.leftAnchor, bottom: self.viewScroll.bottomAnchor, right: self.view.rightAnchor, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: self.screenSizeWidth, heightConstant: self.screenSizeHeight/2 + 140)
                                                               print(555555555)
                                                    }else {
                                                        self.view.window?.rootViewController = TabBarController()
                                                        self.view.window?.makeKeyAndVisible()
                                                    }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                      } else {
                      print("Error: \(error!.localizedDescription)")
                        self.textError.text = error!.localizedDescription
                        }
                    }
                }
            }
        }else {
            
        }
    
//        guard let name = nameTextField.text, let email = emailTextField.text, let password = passwordTextField.text, let confirmpassword = passwordConfirmTextField.text, let age = ageTextField.text, let height = heightTextField.text, let weight =  weightTextField.text, let bloodsugar = bloodSugarTextField.text, let gestationalAge = gestationalAgeTextField.text, let weightbefore = weightBeforeTextField.text else{ return }
//
//        let gestationalAges = (gestationalAge as NSString).doubleValue
//        let ages = (age as NSString).doubleValue
//        let heights = (height as NSString).doubleValue
//        let weightbefores = (weightbefore as NSString).doubleValue
//        let weights = (weight as NSString).doubleValue
//        let bloodsugars = (bloodsugar as NSString).doubleValue

    }
    
//-----------------------------------------------------------------------------------------------------------------
   
    override func viewWillAppear(_ animated: Bool) {
        setUI()
       
        
    }
    func setUI() {
        if registerViewController.page == 1 {
            weightView.isHidden = true
            heightView.isHidden = true
            weightBeforeView.isHidden = true
            ageView.isHidden = true
            gestationalAgeView.isHidden = true
            bloodSugarView.isHidden = true
            iconRegister.image = UIImage(named: "iconRegister01")
            pageControllOne.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1)
            pageControllTwo.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllThree.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllFour.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
           
        }else if registerViewController.page == 2 {
            nameView.isHidden = true
            emailView.isHidden = true
            passwordView.isHidden = true
            passwordConfirmView.isHidden = true
            ageView.isHidden = true
            gestationalAgeView.isHidden = true
            bloodSugarView.isHidden = true
            iconRegister.image = UIImage(named: "iconRegister02")
            pageControllOne.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllTwo.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1)
            pageControllThree.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllFour.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
    
            viewPageTwo.anchor(backgroundUIView.topAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 0, leftConstant: 40, bottomConstant: 0, rightConstant: 40, widthConstant: 0, heightConstant: screenSizeHeight/8 + 30)
            
            stacView.anchor(viewPageTwo.bottomAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 30,  leftConstant: 40, bottomConstant: 0, rightConstant: 40, widthConstant: 0, heightConstant: CGFloat(Field01+Field02+Field03))
            
            backgroundUIView.anchor(stacViewPageControll.bottomAnchor, left: view.leftAnchor, bottom: viewScroll.bottomAnchor, right: view.rightAnchor, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth, heightConstant: screenSizeHeight/2 + 130)
            
            viewPageTwo.isHidden = false
            titleBMI.isHidden = false
            boxNumber.isHidden = false
            Number.isHidden = false
            textOput.isHidden = false
            textOputResults.isHidden = false
            textOput2.isHidden = false
            textOputResults2.isHidden = false
            OputResultsbuttonline.isHidden = false
            
        }else if registerViewController.page == 3 {
            nameView.isHidden = true
            emailView.isHidden = true
            passwordView.isHidden = true
            passwordConfirmView.isHidden = true
            weightView.isHidden = true
            heightView.isHidden = true
            weightBeforeView.isHidden = true
            bloodSugarView.isHidden = true
            iconRegister.image = UIImage(named: "iconRegister03")
            pageControllOne.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllTwo.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllThree.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1)
            pageControllFour.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            
            stacView.anchor(backgroundUIView.topAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 30,  leftConstant: 40, bottomConstant: 0, rightConstant: 40, widthConstant: 0, heightConstant: CGFloat(Field01+Field02))
            
            backgroundUIView.anchor(stacViewPageControll.bottomAnchor, left: view.leftAnchor, bottom: viewScroll.bottomAnchor, right: view.rightAnchor, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth, heightConstant: screenSizeHeight/2 + 80)
            
        }else if registerViewController.page == 4 {
            nameView.isHidden = true
            emailView.isHidden = true
            passwordView.isHidden = true
            passwordConfirmView.isHidden = true
            weightView.isHidden = true
            heightView.isHidden = true
            weightBeforeView.isHidden = true
            ageView.isHidden = true
            gestationalAgeView.isHidden = true
            iconRegister.image = UIImage(named: "iconRegister04")
            pageControllOne.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllTwo.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllThree.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 0.3)
            pageControllFour.backgroundColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1)
            
            stacView.anchor(backgroundUIView.topAnchor, left: backgroundUIView.leftAnchor, bottom: nil, right: backgroundUIView.rightAnchor, topConstant: 30,  leftConstant: 40, bottomConstant: 0, rightConstant: 40, widthConstant: 0, heightConstant: CGFloat(Field01 - 20))
            
            backgroundUIView.anchor(stacViewPageControll.bottomAnchor, left: view.leftAnchor, bottom: viewScroll.bottomAnchor, right: view.rightAnchor, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: screenSizeWidth, heightConstant: screenSizeHeight/2 + 80)
        }
    }
    
//-----------------------------------------------------------------------------------------------------------------
    
    @objc func handleTap(sender: UITapGestureRecognizer){

        self.view.endEditing(true)
        
    }
    
}
