//
//  registerViewController.swift
//  SweetMom
//
//  Created by kantapong on 18/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit
import FirebaseFirestore
import FirebaseAuth

class registerViewController: UIViewController, UITextFieldDelegate {
    
    var dataUser : User?
    
    
    let nameTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "Name", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(checkOnClick), for: .editingChanged)
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    let emailTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "Email Address",attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(handelemailCheckValid), for: .editingChanged)
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        textField.keyboardType = .emailAddress
        return textField
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    let passwordTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "Password (8 characters)", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 12), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(handlepasswordCheckValid), for: .editingChanged)
        textField.isSecureTextEntry = true
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    let passwordTextFieldII: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "Password (8 characters)", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 12), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(handlepasswordCheckValid), for: .editingChanged)
        textField.isSecureTextEntry = true
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    let weightTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "weight", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(checkOnClick), for: .editingChanged)
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()
    
    let heightTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "height", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(checkOnClick), for: .editingChanged)
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()
    
    let weightBeforeTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "weightBefore", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(checkOnClick), for: .editingChanged)
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()
    let ageTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "age", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(checkOnClick), for: .editingChanged)
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()
    let gestationalAgeTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "gestationalAge", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(checkOnClick), for: .editingChanged)
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()
    
    let bloodSugarTextField: UITextField = {
        let textField = UITextField()
        textField.attributedPlaceholder = NSAttributedString(string: "bloodSugar", attributes: [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15), NSAttributedString.Key.foregroundColor: UIColor.blackAlpha(alpha: 0.5)])
        textField.textColor = .black
        //textField.addTarget(self, action: #selector(checkOnClick), for: .editingChanged)
        textField.font = UIFont.boldSystemFont(ofSize: 15)
        return textField
    }()


//-----------------------------------------------------------------------------------------------------------------


    let LoginButton: UIButton = {
        var button = UIButton(type: .system)
        let gradientLayer = CAGradientLayer()
        button.frame = CGRect(x: 0, y: 0, width: 400, height: 70)
        gradientLayer.frame = button.frame
        gradientLayer.colors = [UIColor.lightPink.cgColor, UIColor.darkPink.cgColor]
        button.layer.insertSublayer(gradientLayer, at: 0)
        button.clipsToBounds = true
        button.layer.cornerRadius = 8
        button.setTitle("Next", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 20)
        button.addTarget(self, action: #selector(handleDone), for: .touchUpInside)
        button.tag = 1
        return button
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        let stacView = UIStackView(arrangedSubviews: [nameTextField,emailTextField,passwordTextField,passwordTextFieldII,weightTextField,heightTextField,weightBeforeTextField,ageTextField,gestationalAgeTextField,bloodSugarTextField])
        stacView.distribution = .fillEqually
        stacView.spacing = 10
        stacView.backgroundColor = .white
        stacView.axis = .vertical

        self.nameTextField.delegate = self
        self.emailTextField.delegate = self
        self.passwordTextField.delegate = self
        self.passwordTextFieldII.delegate = self
        
        self.weightTextField.delegate = self
        self.heightTextField.delegate = self
        self.weightBeforeTextField.delegate = self
        self.ageTextField.delegate = self
        self.gestationalAgeTextField.delegate = self
        self.bloodSugarTextField.delegate = self
        
        view.addSubview(stacView)
        view.addSubview(LoginButton)
        
        stacView.anchor(view.safeAreaLayoutGuide.topAnchor, left: view.leftAnchor, bottom: nil, right: view.rightAnchor, topConstant: 50, leftConstant: 10, bottomConstant: 0, rightConstant: 10, widthConstant: 0, heightConstant: 0)
        LoginButton.anchor(stacView.bottomAnchor, left: view.leftAnchor, bottom: nil, right: view.rightAnchor, topConstant: 20, leftConstant: 10, bottomConstant: 0, rightConstant: 10, widthConstant: 0, heightConstant: 0)
        // Do any additional setup after loading the view.
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    @objc func handleDone(_sender: UIButton){
        guard let name = nameTextField.text, let email = emailTextField.text, let password = passwordTextField.text, let confirmpassword = passwordTextFieldII.text, let age = ageTextField.text, let height = heightTextField.text, let weight =  weightTextField.text, let bloodsugar = bloodSugarTextField.text, let gestationalAge = gestationalAgeTextField.text, let weightbefore = weightBeforeTextField.text else{ return }
        
        let gestationalAges = (gestationalAge as NSString).doubleValue
        let ages = (age as NSString).doubleValue
        let heights = (height as NSString).doubleValue
        let weightbefores = (weightbefore as NSString).doubleValue
        let weights = (weight as NSString).doubleValue
        let bloodsugars = (bloodsugar as NSString).doubleValue
        Auth.auth().createUser(withEmail: email, password: password) { authResult, err in
            if err != nil {
                // There was an error creating the user
                //self.showError("Error creating user")
            }else {
                let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.displayName = name
                
                changeRequest?.commitChanges { (error) in
                  if error == nil {
                      print("User display name changed!")
                    
                      let db = Firestore.firestore()
                    db.collection("users").document(authResult!.user.uid).setData(["FullName" : name,"Age" : ages,"GestationalAge" : gestationalAges,"Height" : heights,"WeightBefore" : weightbefores,"uid" : authResult!.user.uid]){(error) in
                          if error != nil {
                          // Show error message
                          print("Error saving user data")
                          }else {
                            db.collection("users").document(authResult!.user.uid).collection("Weights").document().setData(["Weight": weights,"date": "\(Date.dateFromCustomString(customString: "\(Date())"))"]){(error) in
                                if error != nil {
                                    // Show error message
                                    print("Error saving user data")
                                }else {
                                    db.collection("users").document(authResult!.user.uid).collection("BloodSugars").document().setData(["bloodSugar": bloodsugars,"date": "\(Date.dateFromCustomString(customString: "\(Date())"))"]){(error) in
                                        if error != nil {
                                        // Show error message
                                            print("Error saving user data")
                                        }else {
                                            self.view.window?.rootViewController = TabBarController()
                                            self.view.window?.makeKeyAndVisible()
                                        }
                                    }
                                }
                            }
                        }
                    }
                  } else {
                  print("Error: \(error!.localizedDescription)")
                }
                }
            }
        }
    }
    
//-----------------------------------------------------------------------------------------------------------------
    
    @objc func keyboardWillShow(notification: NSNotification) {
          if self.view.frame.origin.y == 0 {
              self.view.frame.origin.y -= 100
                        //keyboardSize.height
          }
      }
    @objc func keyboardWillHide(notification: NSNotification) {
          if self.view.frame.origin.y != 0 {
              self.view.frame.origin.y = 0
          }
      }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    
    }
    
}
