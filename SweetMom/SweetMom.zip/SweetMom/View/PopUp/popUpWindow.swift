//
//  popUpWindow.swift
//  SweetMom
//
//  Created by kantapong on 19/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

protocol PopUpDelegate {
    
    func handleDismissal()
    
}
class PopUpWindow: UIView {
    

    var cal = 0
    let screenSizeWidth: CGFloat = UIScreen.main.bounds.width
    var name : String = ""
    var delegate: PopUpDelegate?
    
    let iconTree: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconPopupTree")
        image.contentMode =  .scaleAspectFit
        image.layer.masksToBounds = true
        return image
    }()
    
    let iconHome: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "iconPopup")
        image.contentMode =  .scaleAspectFit
        image.layer.masksToBounds = true
        return image
    }()
    
    let headUIView: UIView = {
           let view = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 60))
           let gradient = CAGradientLayer()
           view.clipsToBounds = true
           view.layer.maskedCorners = [.layerMinXMinYCorner /*top left corner*/, .layerMaxXMinYCorner /*top right corner*/]
           gradient.frame = view.bounds
           gradient.colors = [UIColor.darkPink.cgColor, UIColor.lightPink.cgColor]
           view.layer.cornerRadius = 8
           gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
           gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
           view.layer.addSublayer(gradient)
           return view
       }()
    let Titlehead: UILabel = {
        let label = UILabel()
        label.text = "สมัครเสร็จสิ้น"
        label.textColor = .white
        label.font = UIFont.Opun(size: 20)
        label.numberOfLines = 0
        return label
    }()
    
    let TitleTextlabel: UILabel = {
        let label = UILabel()
        label.text = "SWEEET MOM"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 30)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
       
    let contentTextlabel: UILabel = {
        let label = UILabel()
        label.text = "ยินดีต้อนรับ \n\n แอปพลิเคชันสำหรับผู้aป่วย \n เบาหวานขณะตั้งครรภ์"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 18)
        label.numberOfLines = 0
        label.textColor = .darkPink
        label.textAlignment = .center
        return label
    }()
   let button: UIButton = {
       let button = UIButton(type: .system)
       let gradientLayer = CAGradientLayer()
       button.frame = CGRect(x: 0, y: 0, width: 400, height: 50)
       gradientLayer.frame = button.frame
       gradientLayer.colors = [UIColor.lightPink.cgColor, UIColor.darkPink.cgColor]
       button.layer.insertSublayer(gradientLayer, at: 0)
       button.clipsToBounds = true
       button.layer.cornerRadius = 8
       button.setTitle("Close", for: .normal)
       button.setTitleColor(.white, for: .normal)
       //button.titleLabel?.font = UIFont.Opun(size: 20)
       button.addTarget(self, action: #selector(handleDismissalss), for: .touchUpInside)
       return button
   }()
//-----------------------------------------------------------------------------------------------------------------
//PhotoView
    let TitleheadleftPhotoView: UILabel = {
        let label = UILabel()
        label.text = "แคลลอรี่(Cal)"
        label.textColor = .black
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    let TitleheadrightPhotoView: UILabel = {
           let label = UILabel()
           label.text = "ค่าดัชนีน้ำตาล(GI)"
           label.textColor = .black
           label.font = UIFont.Opun(size: 14)
           label.numberOfLines = 0
           return label
       }()
    
    let boxCalPhotoView: UIView = {
        let view = UIView()
        view.backgroundColor = .palePink
        view.layer.cornerRadius = 8
        view.layer.maskedCorners = [.layerMinXMinYCorner , .layerMinXMaxYCorner]
        return view
    }()
    
    let numCal: UILabel = {
        let label = UILabel()
        label.text = "60"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 18)
        label.numberOfLines = 0
        return label
    }()
    
    let spaceBoxPhotoView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()

    let boxGIPhotoView: UIView = {
        let view = UIView()
        view.backgroundColor = .palePink
        view.layer.cornerRadius = 8
        view.layer.maskedCorners = [.layerMaxXMinYCorner , .layerMaxXMaxYCorner]
        return view
    }()
    
    let numGI: UILabel = {
        let label = UILabel()
        label.text = "75"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 18)
        label.numberOfLines = 0
        return label
    }()
    
    let progressView: UIProgressView = {
        let view = UIProgressView()
        view.progressImage = UIImage(named: "progress")
        view.progress = 0.7
        view.trackTintColor = .palePink
        view.progressViewStyle = .bar
        view.layer.cornerRadius = 15
        view.translatesAutoresizingMaskIntoConstraints = false
        view.clipsToBounds = true
        return view
    }()
       
    let calMaxLabel: UILabel = {
        let label = UILabel()
        label.text = "2500"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
       
    let sumCalPhotoView: UILabel = {
        let label = UILabel()
        label.text = "รวมแคลลอรี่ของวันนี้"
        label.textColor = .black
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    let calLabel: UILabel = {
        let label = UILabel()
        label.text = "700"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 12)
        label.numberOfLines = 0
        return label
    }()
       
    let lineCal: UIView = {
        let view = UIView()
        view.backgroundColor = .darkPink
        return view
    }()
    
    let lineSpace: UIView = {
        let view = UIView()
        view.backgroundColor = .lightGray
        return view
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    let boxFat: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.borderColor = UIColor.yellow.cgColor
        view.layer.borderWidth = 2
        view.layer.cornerRadius = 20
        return view
    }()
    
    let numberFat: UILabel = {
        let label = UILabel()
        label.text = "0.4"
        label.textColor = .yellow
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
    let labelFat: UILabel = {
        let label = UILabel()
        label.text = "ไขมัน"
        label.textColor =  .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    let boxProtein: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.borderColor = UIColor.red.cgColor
        view.layer.borderWidth = 2
        view.layer.cornerRadius = 20
        return view
    }()
    
    let numberProtein: UILabel = {
        let label = UILabel()
        label.text = "0.4"
        label.textColor = .red
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
    let labelProtein: UILabel = {
        let label = UILabel()
        label.text = "โปรตีน"
        label.textColor = .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    let boxCarbohydrate: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.borderColor = UIColor.purple.cgColor
        view.layer.borderWidth = 2
        view.layer.cornerRadius = 20
        return view
    }()
    
    let numberCarbohydrate: UILabel = {
        let label = UILabel()
        label.text = "0.4"
        label.textColor = .purple
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
    let labelCarbohydrate: UILabel = {
        let label = UILabel()
        label.text = "คาร์โบฯ"
        label.textColor = .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    let boxSodium: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.borderColor = UIColor.blue.cgColor
        view.layer.borderWidth = 2
        view.layer.cornerRadius = 20
        return view
    }()
    
    let numberSodium: UILabel = {
        let label = UILabel()
        label.text = "0.4"
        label.textColor = .blue
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
    let labelSodium: UILabel = {
        let label = UILabel()
        label.text = "โซเดียม"
        label.textColor = .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
//-----------------------------------------------------------------------------------------------------------------
    
    let buttonClosePhotoView: UIButton = {
        let button = UIButton(type: .system)
        let gradientLayer = CAGradientLayer()
        button.frame = CGRect(x: 0, y: 0, width: 400, height: 50)
        gradientLayer.frame = button.frame
        gradientLayer.colors = [UIColor.palePink.cgColor, UIColor.white.cgColor]
        button.layer.insertSublayer(gradientLayer, at: 0)
        button.clipsToBounds = true
        button.layer.cornerRadius = 8
        button.setTitle("ยกเลิก", for: .normal)
        button.setTitleColor(.darkPink, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 12)
        button.addTarget(self, action: #selector(handleDismissalss), for: .touchUpInside)
        return button
    }()
    let spaceButton: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    let buttonSavePhotoView: UIButton = {
        let button = UIButton(type: .system)
        let gradientLayer = CAGradientLayer()
        button.frame = CGRect(x: 0, y: 0, width: 400, height: 50)
        gradientLayer.frame = button.frame
        gradientLayer.colors = [UIColor.lightPink.cgColor, UIColor.darkPink.cgColor]
        button.layer.insertSublayer(gradientLayer, at: 0)
        button.clipsToBounds = true
        button.layer.cornerRadius = 8
        button.setTitle("บันทึก", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.Opun(size: 12)
        button.addTarget(self, action: #selector(handleSave), for: .touchUpInside)
        return button
    }()
    
//-----------------------------------------------------------------------------------------------------------------

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        
        addSubview(button)
        addSubview(TitleTextlabel)
        addSubview(contentTextlabel)
        addSubview(headUIView)
        addSubview(iconTree)
        addSubview(iconHome)
        headUIView.addSubview(Titlehead)
        

       
        iconHome.anchor(nil, left: nil, bottom: topAnchor, right: rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: -50, widthConstant: 220, heightConstant: 220)
        
        iconTree.anchor(nil, left: leftAnchor, bottom: topAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: -20, rightConstant: 0, widthConstant: 80, heightConstant: 100)
        
        headUIView.anchor(topAnchor, left: leftAnchor, bottom: nil, right: rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 60)
        
        Titlehead.anchor(headUIView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        Titlehead.centerXAnchor.constraint(equalTo: headUIView.centerXAnchor).isActive = true
        
        TitleTextlabel.anchor(headUIView.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 40, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        TitleTextlabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
               
        contentTextlabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        contentTextlabel.topAnchor.constraint(equalTo: TitleTextlabel.bottomAnchor, constant: 10).isActive = true
        
        button.anchor(nil, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 0, leftConstant: 40, bottomConstant: 20, rightConstant: 40, widthConstant: 0, heightConstant: 50)
        
//-----------------------------------------------------------------------------------------------------------------
//PhotoView
        addSubview(TitleheadleftPhotoView)
        addSubview(TitleheadrightPhotoView)
        addSubview(boxCalPhotoView)
        addSubview(spaceBoxPhotoView)
        addSubview(boxGIPhotoView)
        boxCalPhotoView.addSubview(numCal)
        boxGIPhotoView.addSubview(numGI)
        
        addSubview(sumCalPhotoView)
        addSubview(progressView)
        addSubview(calMaxLabel)
        addSubview(calLabel)
        addSubview(lineCal)
        addSubview(lineSpace)
        
        TitleheadleftPhotoView.anchor(headUIView.bottomAnchor, left: headUIView.leftAnchor, bottom: nil, right: nil, topConstant: 20, leftConstant: 20, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        TitleheadrightPhotoView.anchor(headUIView.bottomAnchor, left: nil, bottom: nil, right: headUIView.rightAnchor, topConstant: 20, leftConstant: 0, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
        
        boxCalPhotoView.anchor(TitleheadleftPhotoView.bottomAnchor, left: headUIView.leftAnchor, bottom: nil, right: spaceBoxPhotoView.leftAnchor, topConstant: 10, leftConstant: 20, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 50)
        
        spaceBoxPhotoView.anchor(TitleheadleftPhotoView.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 2, heightConstant: 50)
        spaceBoxPhotoView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        
        boxGIPhotoView.anchor(TitleheadrightPhotoView.bottomAnchor, left: spaceBoxPhotoView.rightAnchor, bottom: nil, right: headUIView.rightAnchor, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 50)
        
        numCal.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        numCal.centerXAnchor.constraint(equalTo: boxCalPhotoView.centerXAnchor).isActive = true
        numCal.centerYAnchor.constraint(equalTo: boxCalPhotoView.centerYAnchor).isActive = true

        numGI.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        numGI.centerXAnchor.constraint(equalTo: boxGIPhotoView.centerXAnchor).isActive = true
        numGI.centerYAnchor.constraint(equalTo: boxGIPhotoView.centerYAnchor).isActive = true
        
        sumCalPhotoView.anchor(boxCalPhotoView.bottomAnchor, left: leftAnchor, bottom: nil, right: nil, topConstant: 10, leftConstant: 20, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        progressView.anchor(sumCalPhotoView.bottomAnchor, left: leftAnchor, bottom: nil, right: calMaxLabel.leftAnchor, topConstant: 0, leftConstant: 10, bottomConstant: 40, rightConstant: 0, widthConstant: screenSizeWidth - 130, heightConstant: 30)
        
        calMaxLabel.anchor(sumCalPhotoView.bottomAnchor, left: progressView.rightAnchor, bottom: nil, right: rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 10, widthConstant: 0, heightConstant: 0)
        
        lineSpace.anchor(calMaxLabel.bottomAnchor, left: leftAnchor, bottom: nil, right: rightAnchor, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 1)
        
//-----------------------------------------------------------------------------------------------------------------
        
        let stacView = UIStackView(arrangedSubviews: [boxFat,boxProtein,boxCarbohydrate,boxSodium])
        stacView.distribution = .fillEqually
        stacView.spacing = 20
        stacView.axis = .horizontal
        
        addSubview(stacView)
        boxFat.addSubview(numberFat)
        boxCarbohydrate.addSubview(numberCarbohydrate)
        boxProtein.addSubview(numberProtein)
        boxSodium.addSubview(numberSodium)
        
        stacView.addSubview(labelFat)
        stacView.addSubview(labelProtein)
        stacView.addSubview(labelCarbohydrate)
        stacView.addSubview(labelSodium)
        
        stacView.anchor(lineSpace.bottomAnchor, left: leftAnchor, bottom: nil, right: rightAnchor, topConstant: 10, leftConstant: 20, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 40)
        
        numberFat.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        numberFat.centerXAnchor.constraint(equalTo: boxFat.centerXAnchor).isActive = true
        numberFat.centerYAnchor.constraint(equalTo: boxFat.centerYAnchor).isActive = true
        
        labelFat.anchor(boxFat.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        labelFat.centerXAnchor.constraint(equalTo: boxFat.centerXAnchor).isActive = true
        
        numberCarbohydrate.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        numberCarbohydrate.centerXAnchor.constraint(equalTo: boxCarbohydrate.centerXAnchor).isActive = true
        numberCarbohydrate.centerYAnchor.constraint(equalTo: boxCarbohydrate.centerYAnchor).isActive = true
        
        labelCarbohydrate.anchor(boxCarbohydrate.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        labelCarbohydrate.centerXAnchor.constraint(equalTo: boxCarbohydrate.centerXAnchor).isActive = true
        
        numberProtein.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        numberProtein.centerXAnchor.constraint(equalTo: boxProtein.centerXAnchor).isActive = true
        numberProtein.centerYAnchor.constraint(equalTo: boxProtein.centerYAnchor).isActive = true
        
        labelProtein.anchor(boxProtein.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        labelProtein.centerXAnchor.constraint(equalTo: boxProtein.centerXAnchor).isActive = true
        
        numberSodium.anchor(nil, left: nil, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        numberSodium.centerXAnchor.constraint(equalTo: boxSodium.centerXAnchor).isActive = true
        numberSodium.centerYAnchor.constraint(equalTo: boxSodium.centerYAnchor).isActive = true
        
        labelSodium.anchor(boxSodium.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 5, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        labelSodium.centerXAnchor.constraint(equalTo: boxSodium.centerXAnchor).isActive = true
        
        addSubview(buttonClosePhotoView)
        addSubview(spaceButton)
        addSubview(buttonSavePhotoView)
        
        buttonClosePhotoView.anchor(labelFat.bottomAnchor, left: leftAnchor, bottom: nil, right: spaceButton.leftAnchor, topConstant: 10, leftConstant: 20, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        spaceButton.anchor(labelFat.bottomAnchor, left: nil, bottom: nil, right: nil, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 2, heightConstant: 20)
        spaceButton.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        
        buttonSavePhotoView.anchor(labelFat.bottomAnchor, left: spaceButton.rightAnchor, bottom: nil, right: rightAnchor, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 20, widthConstant: 0, heightConstant: 0)
        
//-----------------------------------------------------------------------------------------------------------------
        
    }
    
     @objc func handleDismissalss() {
        
        delegate?.handleDismissal()
        
       
    }
     @objc func handleSave() {
       
        //dataUser?[0].userCaloriesPerDay +=
        //let home = HomeViewController()
        HomeViewController.updateCal = cal
        print(cal)
        window?.rootViewController = TabBarController()
        window?.makeKeyAndVisible()
        delegate?.handleDismissal()
        
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
