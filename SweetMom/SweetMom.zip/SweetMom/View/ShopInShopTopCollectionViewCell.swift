//
//  ShopInShopTopCollectionViewCell.swift
//  SweetMom
//
//  Created by kantapong on 8/3/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class ShopInShopTopCollectionViewCell: UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViewCell()
    }
    
    var dataShop: Shop? {
        didSet{
            
        }
    }
    func setupViewCell() {
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
