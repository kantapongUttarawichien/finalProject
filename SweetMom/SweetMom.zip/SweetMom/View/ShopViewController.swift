//
//  ShopViewController.swift
//  SweetMom
//
//  Created by kantapong on 21/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class ShopViewController: UITableViewController, UISearchBarDelegate, UISearchResultsUpdating {
    override var preferredStatusBarStyle: UIStatusBarStyle {
      return .darkContent
    }
    var dataShop = Shop.shop()
    let searchController = UISearchController(searchResultsController: nil)
    var checkSearchResults: Bool = false
    
    private var cellId = "Cell"
    private var cellSearchHistory = "Search History Cell"
    private var cellRecentlyViewed = "Recently Viewed Cell"
    
    var keywords = KeywordSuggestions.keywords()
    var filterKeyword = [KeywordSuggestions]()
    
     let backgroundPage: UIImageView = {
           let image = UIImageView()
           image.image = UIImage(named: "backgroundHomePage")
           image.contentMode =  .scaleAspectFill
           image.layer.masksToBounds = true
           return image
       }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        navigationItem.title = "ร้านค้า"
        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.font: UIFont.Opun(size: 30), NSAttributedString.Key.foregroundColor: UIColor.black]
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: UIFont.Opun(size: 20), NSAttributedString.Key.foregroundColor: UIColor.black]
        
        
        let basket = UIBarButtonItem(image: #imageLiteral(resourceName: "iconBasket").withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(basketPage))
        
        navigationController?.navigationBar.prefersLargeTitles = true
        searchController.searchResultsUpdater = self
        searchController.searchBar.delegate = self
        searchController.searchBar.placeholder = "Search"
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.tintColor = .gray
        
        navigationItem.searchController = searchController
        navigationItem.rightBarButtonItems = [basket]
        navigationItem.hidesSearchBarWhenScrolling = false
        tableView.register(ShopTableViewCell.self, forCellReuseIdentifier: cellId)
        tableView.register(SearchHistoryCell.self, forCellReuseIdentifier: cellSearchHistory)
        tableView.register(ShopTopTableViewCell.self, forCellReuseIdentifier: cellRecentlyViewed)
        tableView.tableFooterView = UIView()
        tableView.showsVerticalScrollIndicator = false
        tableView.separatorStyle = .none
        view.backgroundColor = .palePink
        
       
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        if checkSearchResults {
           return 1
        } else {
            return 2
        }
          
       }

       override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
            if checkSearchResults {
                
                return filterKeyword.count
                
            } else {
                
                if section == 0 {
                    return 1
                } else {
                    return dataShop.count
                }
                
            }
        
       }
       
       override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            if checkSearchResults {
                
                let cell = tableView.dequeueReusableCell(withIdentifier: cellSearchHistory, for: indexPath) as! SearchHistoryCell
                
                cell.selectionStyle = .none
                
                cell.titleTextLabel.text = filterKeyword[indexPath.row].keyword
                
                return cell
                
            } else {
                
                if indexPath.section == 0{
                    
                    let cell = tableView.dequeueReusableCell(withIdentifier: cellRecentlyViewed, for: indexPath) as! ShopTopTableViewCell
                        cell.selectionStyle = .none
                        cell.dataShop = dataShop

                    return cell
                    
                } else {
                    
                    let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! ShopTableViewCell
                       cell.selectionStyle = .none
                    let group = dataShop[indexPath.row]
                    cell.imagHead.image = group.img
                    cell.name.text = group.name
                    cell.price.text = "ราคา \(group.price) บาท"
                       
                       return cell
                    
                }
                
            }
           
       }
//    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//       return 50
//
//    }
    @objc func basketPage() {
        
    }
    func updateSearchResults(for searchController: UISearchController) {
        guard let searchText = searchController.searchBar.text else { return }
        
        if searchText.count > 0 {
            
            filterKeywordSuggestions(searchText)
            
            checkSearchResults = true
            tableView.reloadData()
            
        } else {
            
            checkSearchResults = false
            tableView.reloadData()
            
        }
    }
    func filterKeywordSuggestions(_ searchText: String) {
        
        filterKeyword = keywords.filter({ (keyword: KeywordSuggestions) -> Bool in
            return keyword.keyword.lowercased().contains(searchText.lowercased())
        })
        
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if checkSearchResults {
            return 50
        } else {
            if indexPath.section == 0 {
                return 420
            } else {
                return 100
            }
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
