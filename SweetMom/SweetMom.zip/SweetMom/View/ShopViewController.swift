//
//  ShopViewController.swift
//  SweetMom
//
//  Created by kantapong on 21/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class ShopViewController: UITableViewController {
    
    var dataShop = Shop.shop()
    private var cellId = "Cell"
     let backgroundPage: UIImageView = {
           let image = UIImageView()
           image.image = UIImage(named: "backgroundHomePage")
           image.contentMode =  .scaleAspectFill
           image.layer.masksToBounds = true
           return image
       }()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        navigationItem.title = "ร้านค้า"
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font:UIFont.Opun(size: 20), NSAttributedString.Key.foregroundColor:UIColor.black]
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        navigationController?.navigationBar.shadowImage = UIImage()
        
        let basket = UIBarButtonItem(image: #imageLiteral(resourceName: "iconBasket").withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(basketPage))
               
        navigationItem.rightBarButtonItems = [basket]
        
        tableView.register(ShopTableViewCell.self, forCellReuseIdentifier: cellId)
        tableView.tableFooterView = UIView()
        tableView.showsVerticalScrollIndicator = false
        tableView.separatorStyle = .none
         view.backgroundColor = .palePink
        
       // view.addSubview(backgroundPage)
        
       // backgroundPage.anchor(view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, topConstant: -60, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        // Do any additional setup after loading the view.
    }
//    override func numberOfSections(in tableView: UITableView) -> Int {
//           return 0
//       }
//
       override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return dataShop.count
          
       }
       
       override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           
           let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! ShopTableViewCell
           cell.selectionStyle = .none
        let group = dataShop[indexPath.row]
        cell.imagHead.image = group.img
        cell.name.text = group.name
        cell.price.text = "ราคา \(group.price) บาท"
           
           return cell
       }
//    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//       return 50
//
//    }
    @objc func basketPage() {
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
