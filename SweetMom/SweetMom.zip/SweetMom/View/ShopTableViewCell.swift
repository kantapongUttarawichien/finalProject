//
//  ShopTableViewCell.swift
//  SweetMom
//
//  Created by kantapong on 1/2/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class ShopTableViewCell: UITableViewCell {
    
    lazy var boxView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.2
        return view
    }()
    
    lazy var imagHead: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "11")
        image.contentMode =  .scaleAspectFill
        image.layer.masksToBounds = true
        image.layer.cornerRadius = 8
        image.layer.maskedCorners = [.layerMinXMinYCorner /*top left corner*/, .layerMinXMaxYCorner /*top right corner*/]
        return image
    }()
    
    lazy var name: UILabel = {
        let label = UILabel()
        label.text = "name"
        label.textColor = .black
        label.font = UIFont.Opun(size: 14)
        label.numberOfLines = 0
        return label
    }()
    
    lazy var price: UILabel = {
        let label = UILabel()
        label.text = "name"
        label.textColor = .black
        label.font = UIFont.Opun(size: 18)
        label.numberOfLines = 0
        return label
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        backgroundColor = .clear
        addSubview(boxView)
        boxView.addSubview(imagHead)
        boxView.addSubview(name)
        boxView.addSubview(price)
        
        
        boxView.anchor(topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 10, leftConstant: 20, bottomConstant: 10, rightConstant: 20, widthConstant: 0, heightConstant: 80)
        
        imagHead.anchor(boxView.topAnchor, left: boxView.leftAnchor, bottom: boxView.bottomAnchor, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 80, heightConstant: 0)
        
        name.anchor(boxView.topAnchor, left: imagHead.rightAnchor, bottom: nil, right: nil, topConstant: 10, leftConstant: 20, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        price.anchor(name.bottomAnchor, left: imagHead.rightAnchor, bottom: boxView.bottomAnchor, right: nil, topConstant: 5, leftConstant: 20, bottomConstant: 5, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        // Configure the view for the selected state
    }

}
