//
//  addTableViewCell.swift
//  SweetMom
//
//  Created by kantapong on 25/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class addTableViewCell: UITableViewCell {
    
    let boxView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 8
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = 0.1
        return view
    }()
    
    let dateLabel: UILabel = {
        let label = UILabel()
        label.text = "23/01/2563"
        label.textColor = .black
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
    let numberLabel: UILabel = {
        let label = UILabel()
        label.text = "46"
        label.textColor = .darkPink
        label.font = UIFont.Opun(size: 10)
        label.numberOfLines = 0
        return label
    }()
    
    let unitLabel: UILabel = {
           let label = UILabel()
           label.text = "gm/dL"
           label.textColor = .black
           label.font = UIFont.Opun(size: 10)
           label.numberOfLines = 0
           return label
       }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        backgroundColor = .white
        setupViewCell()
        // Configure the view for the selected state
    }
    func setupViewCell(){
        addSubview(boxView)
        addSubview(dateLabel)
        addSubview(numberLabel)
        addSubview(unitLabel)
        
        boxView.anchor(topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 10, leftConstant: 10, bottomConstant: 10, rightConstant: 10, widthConstant: 0, heightConstant: 40)
        
        dateLabel.anchor(boxView.topAnchor, left: boxView.leftAnchor, bottom: nil, right: nil, topConstant: 10, leftConstant: 5, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        numberLabel.anchor(boxView.topAnchor, left: nil, bottom: nil, right: nil, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        numberLabel.centerXAnchor.constraint(equalTo: boxView.centerXAnchor).isActive = true
        
        unitLabel.anchor(boxView.topAnchor, left: nil, bottom: nil, right: boxView.rightAnchor, topConstant: 10, leftConstant: 0, bottomConstant: 0, rightConstant: 5, widthConstant: 0, heightConstant: 0)
        
    }

}
