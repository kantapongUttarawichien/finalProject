//
//  userBloodSugars.swift
//  SweetMom
//
//  Created by kantapong on 25/2/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit


class userBloodSugars {
    
    var BloodSugarUpdate : Double
    var date : String
   
    
    init(BloodSugarUpdate : Double, date : String) {
        
            self.BloodSugarUpdate = BloodSugarUpdate
            self.date = date
        
       }
}
