//
//  user.swift
//  SweetMom
//
//  Created by kantapong on 25/1/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class User {
    var userFullName : String
    var userEmail : String
    var userPassword : String
    var userWeight : [Double]
    var userWeightBefore : Double
    var userHeight : Double
    var userAge : Int
    var userGestationalAge : Int
    var uerBloodSugar : [Double]
    var userCaloriesPerDay : Double
    var userMaxCal : Int
    
    init(userFullName : String, userEmail : String, userPassword : String, userWeight : [Double], userWeightBefore : Double, userHeight : Double, userAge : Int, userGestationalAge : Int, uerBloodSugar : [Double], userCaloriesPerDay: Double, userMaxCal: Int) {
        
            self.userFullName = userFullName
            self.userEmail = userEmail
            self.userPassword = userPassword
            self.userWeight = userWeight
            self.userWeightBefore = userWeightBefore
            self.userHeight = userHeight
            self.userAge = userAge
            self.userGestationalAge = userGestationalAge
            self.uerBloodSugar = uerBloodSugar
            self.userCaloriesPerDay = userCaloriesPerDay
            self.userMaxCal = userMaxCal
        
       }
    
    static func user() -> [User] {
        var userProfile = [User]()
        userProfile.append(User(userFullName: "Kanyawee Kittiprakarn", userEmail: "Kanyawee@hotmail.com", userPassword: "123456789", userWeight: [56,54,53], userWeightBefore: 52, userHeight: 158, userAge: 22, userGestationalAge: 16, uerBloodSugar: [156], userCaloriesPerDay: 1000, userMaxCal: 2500))
        
        return userProfile
    }
    
    
}
