//
//  Meal.swift
//  SweetMom
//
//  Created by kantapong on 8/2/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class Meal {
   
    var name : String
    var img : UIImage
    var id : Int
    
    init(name : String, img : UIImage, id : Int){
        self.name = name
        self.id = id
        self.img = img

    }
    static func meal() -> [Meal] {
        var usermeal = [Meal]()
        usermeal.append(Meal(name: "มื้อเช้า", img: UIImage(named: "iconMeal_01")!, id: 0))
        usermeal.append(Meal(name: "มื้อว่างเช้า", img: UIImage(named: "iconMeal_02")!, id: 1))
        usermeal.append(Meal(name: "มื้อกลางวัน", img: UIImage(named: "iconMeal_02")!, id: 2))
        usermeal.append(Meal(name: "มื้อว่างบ่าย", img: UIImage(named: "iconMeal_03")!, id: 3))
        usermeal.append(Meal(name: "มื้อเย็น", img: UIImage(named: "iconMeal_04")!, id: 4))
        
        return usermeal
    }
}
