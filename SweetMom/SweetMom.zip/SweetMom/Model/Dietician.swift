//
//  Dietician.swift
//  SweetMom
//
//  Created by kantapong on 1/2/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class Dietician {
    var img : UIImage
    var dieticianFullName : String
    var education : String
    var work : String
    var id : Int
    
    init(img : UIImage,dieticianFullName : String,education : String,work : String,id : Int){
        self.dieticianFullName = dieticianFullName
        self.education = education
        self.work = work
        self.img = img
        self.id = id
    }
    static func dietician() -> [Dietician] {
        var userProfile = [Dietician]()
        userProfile.append(Dietician(img: UIImage(named: "01")!, dieticianFullName: "ออม กิตติพร", education: "จบการศึกษา คณะเทคโนโลยีการอาหาร จุฬาลงกรณ์มหาวิทยาลัย", work: "เป็นนักโภชนาการ ที่ โรงพยาบาลมหิดล ผ่านการอบรมหลักสูตรวิชาการ มากกว่า 30 โครงการ", id: 0))
        userProfile.append(Dietician(img: UIImage(named: "02")!, dieticianFullName: "วรรณพร สวัสดี", education: "จบการศึกษา คณะเทคโนโลยีการอาหาร ศิลปากรมหาวิทยาลัย", work: "เป็นนักโภชนาการ ที่ โรงพยาบาลมหิดล ผ่านการอบรมหลักสูตรวิชาการ มากกว่า 20 โครงการ", id: 1))
        userProfile.append(Dietician(img: UIImage(named: "01")!, dieticianFullName: "สุชาดา กิจภารัตน์", education: "จบการศึกษา คณะเทคโนโลยีการอาหาร มหิดลมหาวิทยาลัย", work: "เป็นนักโภชนาการ ที่ โรงพยาบาลมหิดล ผ่านการอบรมหลักสูตรวิชาการ มากกว่า 40 โครงการ", id: 2))
        
        return userProfile
    }
}
