//
//  Shop.swift
//  SweetMom
//
//  Created by kantapong on 1/2/2563 BE.
//  Copyright © 2563 kantapong. All rights reserved.
//

import UIKit

class Shop {
    var img : UIImage
    var name : String
    var price : Int
    var details : String
    
    init(img : UIImage,name : String, price : Int, details : String){
        self.name = name
        self.price = price
        self.details = details
        self.img = img
    }
    static func shop() -> [Shop] {
        var usershop = [Shop]()
        usershop.append(Shop(img: UIImage(named: "11")!, name: "Folic Acid", price: 980, details: "โฟลิค Folic Acid โฟเลต 800mcg 100 เม็ด (Sundown Naturals) บำรุงครรภ์ บำรุงเลือด"))
        usershop.append(Shop(img: UIImage(named: "12")!, name: "ข้าวกข. 43", price: 90, details: "โฟลิค Folic Acid โฟเลต 800mcg 100 เม็ด (Sundown Naturals) บำรุงครรภ์ บำรุงเลือด"))
        usershop.append(Shop(img: UIImage(named: "13")!, name: "เครื่องตรวจน้ำตาล", price: 1500, details: "โฟลิค Folic Acid โฟเลต 800mcg 100 เม็ด (Sundown Naturals) บำรุงครรภ์ บำรุงเลือด"))
        
        return usershop
    }
}
