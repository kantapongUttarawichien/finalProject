//
//  KeywordSuggestions.swift
//  Item Search
//
//  Created by Wittaya Malaratn on 6/26/18.
//  Copyright © 2018 Wittaya Malaratn. All rights reserved.
//

import Foundation

struct KeywordSuggestions {
    
    let keyword: String
    
    init(keyword: String) {
        self.keyword = keyword
    }
    
    static func keywords() -> [KeywordSuggestions] {
        
        var keywords = [KeywordSuggestions]()
        
        keywords.append(KeywordSuggestions(keyword: "Shoes"))
        keywords.append(KeywordSuggestions(keyword: "Sneakers"))
        keywords.append(KeywordSuggestions(keyword: "Sandals"))
        keywords.append(KeywordSuggestions(keyword: "Pumps"))
        keywords.append(KeywordSuggestions(keyword: "Boots"))
        keywords.append(KeywordSuggestions(keyword: "Flats"))
        
        keywords.append(KeywordSuggestions(keyword: "Sunglasses"))
        keywords.append(KeywordSuggestions(keyword: "Belts"))
        keywords.append(KeywordSuggestions(keyword: "Scarves"))
        keywords.append(KeywordSuggestions(keyword: "Gloves"))
        keywords.append(KeywordSuggestions(keyword: "Hats & Caps"))
        
        keywords.append(KeywordSuggestions(keyword: "Handbags"))
        keywords.append(KeywordSuggestions(keyword: "Leather handbags"))
        keywords.append(KeywordSuggestions(keyword: "Crossbody handbags"))
        keywords.append(KeywordSuggestions(keyword: "Boho handbags"))
        keywords.append(KeywordSuggestions(keyword: "Shoulder handbags"))
        keywords.append(KeywordSuggestions(keyword: "Tote handbags"))
        keywords.append(KeywordSuggestions(keyword: "Wallets"))
        
        keywords.append(KeywordSuggestions(keyword: "Dress"))
        keywords.append(KeywordSuggestions(keyword: "Bohemian dress"))
        keywords.append(KeywordSuggestions(keyword: "Summer dress"))
        keywords.append(KeywordSuggestions(keyword: "Casual dress"))
        keywords.append(KeywordSuggestions(keyword: "Long dress"))
        keywords.append(KeywordSuggestions(keyword: "Party dress"))
        keywords.append(KeywordSuggestions(keyword: "Long black dress"))
        keywords.append(KeywordSuggestions(keyword: "Long floral dress"))
        keywords.append(KeywordSuggestions(keyword: "Boho long dress"))
        keywords.append(KeywordSuggestions(keyword: "Summer casual dress"))
        keywords.append(KeywordSuggestions(keyword: "Casual dress with pockets"))
        
        keywords.append(KeywordSuggestions(keyword: "Pants"))
        keywords.append(KeywordSuggestions(keyword: "Long pants"))
        keywords.append(KeywordSuggestions(keyword: "Short pants"))
        keywords.append(KeywordSuggestions(keyword: "Black pants"))
        keywords.append(KeywordSuggestions(keyword: "Pajama pants"))
        keywords.append(KeywordSuggestions(keyword: "Sleep pants"))
        
        keywords.append(KeywordSuggestions(keyword: "Skirts"))
        keywords.append(KeywordSuggestions(keyword: "Long skirt"))
        keywords.append(KeywordSuggestions(keyword: "Short skirt"))
        keywords.append(KeywordSuggestions(keyword: "Floral skirt"))
        keywords.append(KeywordSuggestions(keyword: "Boho skirt"))
        
        keywords.append(KeywordSuggestions(keyword: "Jeans"))
        keywords.append(KeywordSuggestions(keyword: "Sweaters"))
        
        keywords.append(KeywordSuggestions(keyword: "Shirt"))
        keywords.append(KeywordSuggestions(keyword: "Cotton shirt"))
        
        return keywords
        
    }
    
}
